document.getElementById('login').addEventListener('submit', async e => {
  e.preventDefault();
  const button = document.getElementById('submit'), error = document.getElementById('error');
  button.disabled = true; error.textContent = '';
  try {
    const response = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: document.getElementById('password').value }) });
    const result = await response.json();
    if (!response.ok) throw Error(result.error || 'Could not sign in.');
    location.replace('/');
  } catch (e) { error.textContent = e.message; button.disabled = false; }
});
