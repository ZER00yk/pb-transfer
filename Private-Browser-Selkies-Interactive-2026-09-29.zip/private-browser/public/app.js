const $ = id => document.getElementById(id);
let state = null, current = 'desktop', selectedLegacy = null, toastTimer;
function toast(message) { const t = $('toast'); t.textContent = message; t.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 3500); }
async function api(url, method = 'GET', value) {
  const result = await fetch(url, { method, headers: value === undefined ? {} : { 'Content-Type': 'application/json' }, body: value === undefined ? undefined : JSON.stringify(value) });
  if (result.status === 401) { location.replace('/login'); throw Error('Sign in required.'); }
  const data = await result.json(); if (!result.ok) throw Error(data.error || 'Request failed.'); return data;
}
async function run(fn) { try { await fn(); } catch (error) { toast(error.message); } }
function element(tag, value, className) { const e = document.createElement(tag); if (value !== undefined) e.textContent = value; if (className) e.className = className; return e; }
function item(title, detail, actions = []) {
  const e = element('div', undefined, 'entry'); e.append(element('strong', title));
  if (detail) e.append(element('small', detail));
  if (actions.length) { const row = element('div', undefined, 'actions'); for (const [label, fn] of actions) { const b = element('button', label); b.onclick = fn; row.append(b); } e.append(row); }
  return e;
}
function activeProfile() { return state?.profiles.find(p => p.id === state.activeProfileId); }
function savedProfile() { return state?.profiles.find(p => p.id === selectedLegacy) || activeProfile(); }
function show(name) {
  current = name;
  for (const section of ['desktop', 'files', 'notes', 'saved']) {
    $(section + 'Panel').classList.toggle('hidden', section !== name);
    $(section + 'Button').classList.toggle('selected', section === name);
  }
  if (name === 'files') run(loadFiles);
  if (name === 'notes' || name === 'saved') run(loadState);
}
async function loadState() {
  state = await api('/api/state');
  const p = activeProfile(); if (!p) return;
  $('notes').replaceChildren(...p.notes.map(n => item(n.url || 'General note', n.text + ' · ' + new Date(n.at).toLocaleString(), [['Delete', () => run(async () => { await api('/api/notes/' + n.id, 'DELETE'); await loadState(); })]])));
  if (!selectedLegacy || !state.profiles.some(profile => profile.id === selectedLegacy)) selectedLegacy = state.activeProfileId;
  $('legacyProfile').replaceChildren(...state.profiles.map(profile => { const option = element('option', profile.name); option.value = profile.id; return option; }));
  $('legacyProfile').value = selectedLegacy;
  renderSaved();
  $('legacyFiles').replaceChildren(...state.downloads.map(d => item(d.name, new Date(d.at).toLocaleString(), [['Download copy', () => { location.href = '/api/legacy-downloads/' + d.id; }]])));
}
function renderSaved() {
  const p = savedProfile(); if (!p) return;
  $('bookmarks').replaceChildren(...p.bookmarks.map(b => item(b.title, b.url, [['Copy URL', () => run(() => navigator.clipboard.writeText(b.url).then(() => toast('URL copied; paste it into remote Chromium.')))] ])));
  renderHistory();
}
function renderHistory() {
  const p = savedProfile(); if (!p) return;
  const q = $('historySearch').value.trim().toLowerCase();
  const rows = p.history.filter(h => (h.title + ' ' + h.url).toLowerCase().includes(q)).slice(0, 100);
  $('history').replaceChildren(...rows.map(h => item(h.title || h.url, h.url + ' · ' + new Date(h.at).toLocaleString(), [['Copy URL', () => run(() => navigator.clipboard.writeText(h.url).then(() => toast('URL copied.')))] ])));
}
async function loadFiles() {
  const files = await api('/api/files');
  $('files').replaceChildren(...files.map(f => item(f.name, (f.bytes / 1024 / 1024).toFixed(2) + ' MB · ' + (f.inProgress ? 'Downloading…' : new Date(f.modified).toLocaleString()),
    f.inProgress ? [] : [['Save to Chromebook', () => { location.href = '/api/files/' + encodeURIComponent(f.name); }], ['Delete', () => run(async () => { await api('/api/files/' + encodeURIComponent(f.name), 'DELETE'); await loadFiles(); })]])));
  if (!files.length) $('files').append(element('p', 'No files yet. Download in Chromium or upload from the Chromebook.'));
}
async function uploadFile(file) {
  await new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/files?name=' + encodeURIComponent(file.name));
    xhr.setRequestHeader('Content-Type', 'application/octet-stream');
    xhr.upload.onprogress = e => { if (e.lengthComputable) $('progress').value = Math.round(e.loaded / e.total * 100); };
    xhr.onload = () => { if (xhr.status === 201) resolve(); else reject(Error(JSON.parse(xhr.responseText || '{}').error || 'Upload failed.')); };
    xhr.onerror = () => reject(Error('Upload failed.'));
    xhr.send(file);
  });
}
for (const name of ['desktop', 'files', 'notes', 'saved']) $(name + 'Button').onclick = () => show(name);
$('fullscreen').onclick = () => $('remote').requestFullscreen().catch(e => toast(e.message));
$('reloadDesktop').onclick = () => { $('remote').src = '/desktop/'; };
$('refreshFiles').onclick = () => run(loadFiles);
$('historySearch').oninput = renderHistory;
$('legacyProfile').onchange = () => { selectedLegacy = $('legacyProfile').value; renderSaved(); };
$('saveNote').onclick = () => run(async () => { await api('/api/notes', 'POST', { text: $('noteText').value }); $('noteText').value = ''; await loadState(); toast('Note saved.'); });
$('signout').onclick = () => run(async () => { await api('/api/logout', 'POST', {}); location.replace('/login'); });
document.querySelectorAll('[data-copy]').forEach(b => b.onclick = () => run(async () => { await navigator.clipboard.writeText(b.dataset.copy); toast('URL copied. Paste it into Chromium using the Selkies clipboard box.'); }));
$('upload').onchange = () => run(async () => {
  $('progress').classList.remove('hidden');
  for (const file of $('upload').files) { $('fileStatus').textContent = 'Uploading ' + file.name; $('progress').value = 0; await uploadFile(file); }
  $('fileStatus').textContent = 'Upload complete. Choose the file in Chromium’s /config/Downloads folder.';
  $('upload').value = ''; $('progress').classList.add('hidden'); await loadFiles();
});
setInterval(() => { if (current === 'files') run(loadFiles); }, 4000);
run(loadState);
