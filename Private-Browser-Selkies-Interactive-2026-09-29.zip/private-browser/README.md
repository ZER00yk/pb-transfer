# Private Browser v2 — interactive Chromium on the OVH VPS

This release replaces the Playwright headless screenshot browser with a human-controlled Chromium desktop streamed by LinuxServer's Selkies client. The Chromebook only needs Chrome. Chromium runs on the existing OVH Ubuntu 26.04 VPS; Caddy continues to serve https://15-204-116-93.sslip.io/ through the existing localhost port 3000. No VNC, CDP, SOCKS, HTTP proxy, or desktop container port is published.

The app's existing owner password protects **every** desktop HTTP request, WebSocket upgrade, file transfer, and management API call. The desktop service is reachable only on the private Compose network. Sign out revokes the app cookie and disconnects active desktop streams. The desktop itself keeps running so sites remain open. Sharing links and remote command messages are disabled.

Chromium's own tabs, address bar, back/forward/reload, bookmarks, searchable history, downloads, and site settings are the main controls. PokéRogue and The Password Game can be entered in its address bar; the dashboard has copyable shortcuts. Selkies provides H.264 streaming, audio, mute/volume, file transfer, explicit clipboard controls, fullscreen, keyboard/mouse input and touch/mobile controls. The Chromebook needs no Linux, SSH, or native remote desktop app.

This is not a CAPTCHA bypass. A datacenter IP or remote desktop may still trigger a challenge; you can interact with an ordinary challenge manually when the site permits it. Account login is not guaranteed by any browser architecture.

## Security and persistence

- The Chromium home, profile and Downloads directory live in a 12 GB LUKS2-encrypted file on the VPS, mounted at /srv/private-browser/chromium. The passphrase is entered through OVH's browser KVM console on installation and **again after each VPS reboot**. The startup wrapper refuses to run Chromium if the encrypted mount marker is absent. The app also refuses file operations when it is locked.
- The old encrypted Docker volume and its MASTER_KEY in the existing .env remain in use for notes, previous bookmarks/history, and old downloads. The installer makes a backup after stopping the old browser normally, and keeps the old source directory intact for rollback. Keep an off-VPS backup of the .env, the old encrypted volume, and the new LUKS file. Losing either key/passphrase loses that data.
- The custom Chromium launcher removes the stock LinuxServer wrapper's --no-sandbox and --test-type flags. It keeps Chromium's site isolation, TLS validation and normal browser security. A custom seccomp profile (from Microsoft's Playwright Docker project, under its included license) permits user namespaces for Chromium's sandbox. The app does not run Playwright or expose a debugging port. Check chrome://sandbox after deployment: if the sandbox cannot start on this VPS, the installer rolls back on startup failure rather than switching to --no-sandbox.
- No seamless clipboard sync: use Selkies' sidebar clipboard box deliberately. Selkies' Files sidebar can upload/download, and the app has a Downloads manager with progress by file size, deletion, and Chromebook download. In a remote website's file picker, use /config/Downloads for files uploaded from the Chromebook.
- The VPS is CPU-only unless you have a GPU. Chromium may use software WebGL/WebGL2; inspect chrome://gpu in the running session. PokéRogue's visual performance and audio must be checked on the actual VPS.

## Deploy from the Chromebook, preserving the current app

The new source must be placed in a **different directory** from the working older deployment. Do not overwrite its .env or Docker volume. The package contains no credentials.

1. Download **Private Browser Source.zip** from the ChatGPT attachment to your Chromebook. The ZIP contains source code only; it excludes .env, cookies and user data. In GitHub's website, create a **private** repository and upload the ZIP as `private-browser-v2.zip`. You can also use an existing private repository. Do not upload secrets, backups, or site cookies.
2. In the OVH browser KVM console, clone that private repository, extract the ZIP to a **new** path, and enter that directory. Replace `YOUR_NAME/YOUR_PRIVATE_REPO` below. Git will prompt for your GitHub username and a fine-grained personal access token with read access to that repository's Contents; paste the token as the password. Do not put the token in the clone URL or shell command. These commands do not touch the older source directory:

       sudo apt-get update && sudo apt-get install -y git unzip
       git clone https://github.com/YOUR_NAME/YOUR_PRIVATE_REPO.git ~/browser-transfer
       mkdir -p ~/private-browser-v2
       unzip -q ~/browser-transfer/private-browser-v2.zip -d ~/private-browser-v2
       cd ~/private-browser-v2/private-browser
       sudo bash deploy/install-vps.sh

   The install script detects the old Compose project, asks for a new encryption passphrase, copies its .env, stops the old browser, backs up its encrypted data, builds both containers, copies the old Chromium profile when present, and checks that the interactive Chromium process starts. The passphrase input does not appear on the console while typing. Caddy does not need an edit.
3. Open https://15-204-116-93.sslip.io/ in Chromebook Chrome and sign in with the **same app password**. Choose Desktop. Test PokéRogue manually, sign into its account, then visit chrome://sandbox and chrome://gpu. Use Selkies' audio toggle and volume slider if audio is initially muted.

After a VPS reboot, use the OVH browser KVM console and run:

       cd ~/private-browser-v2/private-browser
       sudo bash deploy/unlock-vps.sh

This prompts for the LUKS passphrase, mounts the profile, and recreates the two app containers. The password is never stored for automatic unlock. Until then, the site may show the login page, but the interactive desktop and file operations remain unavailable.

To restore the previous working app:

       cd ~/private-browser-v2/private-browser
       sudo bash deploy/rollback-vps.sh

This starts the prior source directory under the original Compose project without deleting the new encrypted profile. It does not restore an older version of notes written after the upgrade. The recorded backup is under /var/lib/private-browser/backups on the VPS.

## Migration details

The installer copies the active old Playwright Chromium user-data directory into the new encrypted home if the new profile is empty. It also creates Downloads/Previous browser bookmarks.html for Chromium's bookmark importer. The prior encrypted notes, history, bookmarks and downloads remain in the management UI. Old cookies are carried by the copied profile when compatible, but Chromium versions and cookie encryption can differ. Be ready to sign into PokéRogue once in the new desktop; future cookies, localStorage, IndexedDB and service workers persist in the LUKS volume.

Chromium's sessionStorage normally lasts for the lifetime of a tab and may not survive a Chromium process restart. Account logins should use persistent cookies or other durable site storage. Websites may expire or revoke sessions on their own.

## Project checks

Run npm ci, npm run check, npm test, and npm audit --omit=dev to verify the Node gateway. The tests use a fake desktop upstream and cover authenticated HTTP, authenticated WebSocket input, sign-out revocation, encrypted data, and file transfer. The deployment script checks that Chromium starts on the actual VPS. It cannot determine in advance how Cloudflare, Google, or PokéRogue will treat that VPS IP.

Architecture: Chromebook Chrome → existing Caddy HTTPS → owner-authenticated Node gateway → private Compose network → Selkies desktop + persistent Chromium → websites.
