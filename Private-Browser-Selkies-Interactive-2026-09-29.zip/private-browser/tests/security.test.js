import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes, scrypt as scryptCallback } from 'node:crypto';
import { promisify } from 'node:util';
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { spawn, execFile as execFileCallback } from 'node:child_process';
import net from 'node:net';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import WebSocket, { WebSocketServer } from 'ws';
import { SecureData } from '../src/secure-data.js';
import { Store } from '../src/store.js';
const scrypt = promisify(scryptCallback);
const execFile = promisify(execFileCallback);

test('encrypted state and downloads reject tampering', async () => {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'browser-crypto-'));
  const secure = new SecureData(randomBytes(32), path.join(dir, 'data'), path.join(dir, 'ram'));
  try {
    await secure.init(); await secure.write('state.enc', Buffer.from('private note'));
    assert.equal((await secure.read('state.enc')).toString(), 'private note');
    assert.equal((await readFile(secure.file('state.enc'))).includes(Buffer.from('private note')), false);
    const source = path.join(dir, 'source'), output = path.join(dir, 'output');
    await writeFile(source, randomBytes(200_000));
    await secure.encryptFile(source, 'downloads/file.enc');
    await secure.decryptFile('downloads/file.enc', output);
    assert.deepEqual(await readFile(output), await readFile(source));
    const altered = await readFile(secure.file('state.enc')); altered[20] ^= 1;
    await writeFile(secure.file('state.enc'), altered);
    await assert.rejects(secure.read('state.enc'));
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('session storage never leaks into the management response', () => {
  const store = new Store({});
  store.state = { version: 1, sessionEpoch: 4, activeProfileId: 'one', profiles: [{ id: 'one', tabs: [{ id: 'tab', session: { entries: [['secret', 'sensitive']] } }], bookmarks: [], history: [], notes: [] }], downloads: [], preferences: {} };
  const safe = JSON.stringify(store.publicState());
  assert.equal(safe.includes('sensitive'), false);
  assert.equal(safe.includes('sessionEpoch'), false);
});

test('previous Chromium profile migrates without overwriting an existing one', async () => {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'browser-migration-'));
  const key = randomBytes(32), data = path.join(dir, 'data'), ram = path.join(dir, 'ram'), home = path.join(dir, 'home');
  const secure = new SecureData(key, data, ram);
  try {
    await secure.init(); await mkdir(home);
    await writeFile(path.join(home, '.private-browser-encrypted'), '');
    const store = new Store(secure); await store.init();
    const id = store.state.activeProfileId;
    await store.mutate(() => store.profile().bookmarks.push({ title: 'PokéRogue', url: 'https://pokerogue.net/', at: Date.now() }));
    const old = path.join(dir, 'profile-' + id);
    await mkdir(path.join(old, 'Default'), { recursive: true });
    await writeFile(path.join(old, 'Default', 'History'), 'existing Chromium data');
    const archive = path.join(dir, 'profile.tgz');
    await execFile('tar', ['-czf', archive, '-C', dir, 'profile-' + id]);
    await secure.encryptFile(archive, 'profiles/' + id + '.enc');
    const env = { ...process.env, MASTER_KEY: key.toString('base64'), BROWSER_HOME: home, DATA_DIR: data, RUNTIME_DIR: ram };
    const script = path.resolve(import.meta.dirname, '../deploy/migrate-profile.mjs');
    await execFile(process.execPath, [script], { env });
    assert.equal((await readFile(path.join(home, '.config/chromium/Default/History'))).toString(), 'existing Chromium data');
    assert.match((await readFile(path.join(home, 'Downloads/Previous browser bookmarks.html'))).toString(), /pokerogue.net/);
    await writeFile(path.join(home, '.config/chromium/Default/History'), 'new data');
    await execFile(process.execPath, [script], { env });
    assert.equal((await readFile(path.join(home, '.config/chromium/Default/History'))).toString(), 'new data');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('desktop, file transfer, and streaming WebSocket share the owner gate', async () => {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'browser-gateway-'));
  const port = await new Promise(resolve => { const s = net.createServer().listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => resolve(p)); }); });
  let upstreamCookies = '';
  const upstream = http.createServer((req, res) => { upstreamCookies = req.headers.cookie || ''; res.end('interactive desktop'); });
  const upstreamWs = new WebSocketServer({ noServer: true });
  upstream.on('upgrade', (req, socket, head) => upstreamWs.handleUpgrade(req, socket, head, ws => ws.on('message', value => ws.send(value))));
  await new Promise(resolve => upstream.listen(0, '127.0.0.1', resolve));
  const origin = 'http://127.0.0.1:' + port, password = 'a-test-password-123456', salt = randomBytes(32);
  const hash = await scrypt(password, salt, 64, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
  const child = spawn(process.execPath, ['src/server.js'], {
    cwd: path.resolve(import.meta.dirname, '..'),
    env: { ...process.env, NODE_ENV: 'test', PORT: String(port), APP_ORIGIN: origin, MASTER_KEY: randomBytes(32).toString('base64'), OWNER_PASSWORD_SALT: salt.toString('base64'), OWNER_PASSWORD_HASH: hash.toString('base64'), DATA_DIR: path.join(dir, 'data'), RUNTIME_DIR: path.join(dir, 'ram'), BROWSER_HOME: path.join(dir, 'chromium'), DESKTOP_HOST: '127.0.0.1', DESKTOP_PORT: String(upstream.address().port) },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let stderr = ''; child.stderr.on('data', d => { stderr += d.toString(); });
  const request = (url, options = {}) => fetch(origin + url, { redirect: 'manual', ...options });
  try {
    for (let i = 0; i < 50; i++) { try { await request('/login'); break; } catch { await new Promise(r => setTimeout(r, 50)); } }
    for (const target of ['/', '/app.js', '/style.css', '/desktop/', '/desktop/api/files']) {
      const r = await request(target); assert.equal(r.status, 302, target);
    }
    assert.equal((await request('/api/state')).status, 401);
    assert.equal((await request('/api/files')).status, 401);
    const deniedWs = await new Promise((resolve, reject) => {
      const ws = new WebSocket('ws://127.0.0.1:' + port + '/desktop/api/websocket', { headers: { Origin: origin } });
      ws.on('unexpected-response', (_, response) => resolve(response.statusCode));
      ws.on('open', () => reject(Error('Unauthenticated desktop WebSocket opened.')));
      ws.on('error', reject);
    });
    assert.equal(deniedWs, 401);
    assert.equal((await request('/login')).status, 200);
    const login = await request('/api/login', { method: 'POST', headers: { Origin: origin, 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) });
    assert.equal(login.status, 200, stderr);
    const cookie = login.headers.get('set-cookie').split(';')[0];
    assert.match(login.headers.get('set-cookie'), /HttpOnly; SameSite=Strict/);
    const page = await request('/desktop/', { headers: { Cookie: cookie } });
    assert.equal(page.status, 200);
    assert.equal(await page.text(), 'interactive desktop');
    assert.equal(upstreamCookies.includes('browser_session='), false);
    assert.equal((await request('/api/files', { headers: { Cookie: cookie } })).status, 503);
    assert.equal((await request('/desktop/upload', { method: 'POST', headers: { Cookie: cookie, Origin: 'https://attacker.example' }, body: 'bad' })).status, 403);
    await mkdir(path.join(dir, 'chromium'));
    await writeFile(path.join(dir, 'chromium', '.private-browser-encrypted'), '');
    const uploaded = await request('/api/files?name=example.txt', { method: 'POST', headers: { Cookie: cookie, Origin: origin, 'Content-Type': 'application/octet-stream' }, body: 'from Chromebook' });
    assert.equal(uploaded.status, 201);
    const name = (await uploaded.json()).name;
    assert.equal((await request('/api/files', { headers: { Cookie: cookie } })).status, 200);
    const downloaded = await request('/api/files/' + encodeURIComponent(name), { headers: { Cookie: cookie } });
    assert.equal(await downloaded.text(), 'from Chromebook');
    assert.equal((await request('/api/files/' + encodeURIComponent(name), { method: 'DELETE', headers: { Cookie: cookie, Origin: origin } })).status, 200);
    const ws = new WebSocket('ws://127.0.0.1:' + port + '/desktop/api/websocket', { headers: { Origin: origin, Cookie: cookie } });
    await new Promise((resolve, reject) => { ws.once('open', resolve); ws.once('error', reject); });
    const echoed = new Promise(resolve => ws.once('message', value => resolve(value.toString())));
    ws.send('keyboard'); assert.equal(await echoed, 'keyboard');
    const note = await request('/api/notes', { method: 'POST', headers: { Origin: origin, Cookie: cookie, 'Content-Type': 'application/json' }, body: JSON.stringify({ text: 'secret test note' }) });
    assert.equal(note.status, 200);
    assert.equal((await readFile(path.join(dir, 'data', 'state.enc'))).includes(Buffer.from('secret test note')), false);
    const closed = new Promise(resolve => ws.once('close', resolve));
    const logout = await request('/api/logout', { method: 'POST', headers: { Origin: origin, Cookie: cookie, 'Content-Type': 'application/json' }, body: '{}' });
    assert.equal(logout.status, 200);
    await closed;
    assert.equal((await request('/desktop/', { headers: { Cookie: cookie } })).status, 302);
  } finally {
    if (child.exitCode === null) { child.kill('SIGTERM'); await new Promise(resolve => child.once('exit', resolve)); }
    upstreamWs.close(); await new Promise(resolve => upstream.close(resolve));
    await rm(dir, { recursive: true, force: true });
  }
});
