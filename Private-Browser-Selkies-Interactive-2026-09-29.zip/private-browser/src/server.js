import http from 'node:http';
import { constants, createReadStream, createWriteStream } from 'node:fs';
import { access, mkdir, open, readdir, readFile, rm, statfs, unlink } from 'node:fs/promises';
import { pipeline } from 'node:stream/promises';
import { Transform } from 'node:stream';
import { randomUUID } from 'node:crypto';
import path from 'node:path';
import { SecureData } from './secure-data.js';
import { Store } from './store.js';
import { DesktopProxy } from './desktop-proxy.js';
import { authConfig, verifyPassword, newSession, authenticated, sessionCookie, clearCookie } from './auth.js';

const config = authConfig(process.env);
const dataDir = process.env.DATA_DIR || path.resolve('private-data');
const runtimeDir = process.env.RUNTIME_DIR || '/dev/shm/private-browser';
const browserHome = process.env.BROWSER_HOME || path.resolve('remote-home');
const downloadsDir = path.join(browserHome, 'Downloads');
const port = Number(process.env.PORT || 3000);
const MAX_UPLOAD = 100 * 1024 * 1024;
const secure = new SecureData(config.key, dataDir, runtimeDir); await secure.init();
if (process.env.NODE_ENV === 'production' && (await statfs(runtimeDir)).type !== 0x01021994) throw new Error('RUNTIME_DIR must be on tmpfs.');
const store = new Store(secure); await store.init();
const desktop = new DesktopProxy();

function headers(res, status, extra = {}) {
  res.writeHead(status, {
    'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY',
    'Content-Security-Policy': "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
    ...(config.origin.protocol === 'https:' ? { 'Strict-Transport-Security': 'max-age=31536000' } : {}), ...extra
  });
}
function json(res, status, value, extra = {}) { headers(res, status, { 'Content-Type': 'application/json; charset=utf-8', ...extra }); res.end(JSON.stringify(value)); }
function hostOkay(req) { return req.headers.host === config.origin.host; }
function originOkay(req) { return req.headers.origin === config.origin.origin; }
function isDesktop(pathname) { return pathname === '/desktop' || pathname.startsWith('/desktop/'); }
async function body(req) {
  if (!req.headers['content-type']?.startsWith('application/json')) throw new Error('JSON request required.');
  let s = '';
  for await (const chunk of req) { s += chunk; if (s.length > 65_536) throw new Error('Request too large.'); }
  return JSON.parse(s || '{}');
}
async function asset(res, file, type) { const data = await readFile(new URL(file, import.meta.url)); headers(res, 200, { 'Content-Type': type }); res.end(data); }
function failure(res, error) {
  if (res.headersSent) return res.end();
  if (error.message === 'Encrypted browser profile is locked.') return json(res, 503, { error: error.message });
  const known = /^(JSON request|Request too|Name |Note |Upload too|Invalid |Only |File not)/.test(error.message);
  json(res, known ? 400 : 503, { error: known ? error.message : 'Temporarily unavailable. Try again.' });
  if (!known) console.error('Request failed:', error.name || 'Error');
}
function fileName(input) {
  if (typeof input !== 'string' || !input || input === '.' || input === '..' || Buffer.byteLength(input) > 255 || /[\\/\x00-\x1f\x7f]/.test(input)) throw new Error('Invalid file name.');
  return input;
}
async function requireEncryptedHome() {
  try { await access(path.join(browserHome, '.private-browser-encrypted')); }
  catch { throw new Error('Encrypted browser profile is locked.'); }
}
async function listFiles() {
  await requireEncryptedHome();
  await mkdir(downloadsDir, { recursive: true, mode: 0o700 });
  const entries = await readdir(downloadsDir, { withFileTypes: true }), result = [];
  for (const entry of entries) {
    if (!entry.isFile()) continue;
    const file = await open(path.join(downloadsDir, entry.name), constants.O_RDONLY | constants.O_NOFOLLOW).catch(() => null);
    if (!file) continue;
    try { const info = await file.stat(); result.push({ name: entry.name, bytes: info.size, modified: info.mtimeMs, inProgress: entry.name.endsWith('.crdownload') }); }
    finally { await file.close(); }
  }
  return result.sort((a, b) => b.modified - a.modified);
}
async function upload(req, res, name) {
  await requireEncryptedHome();
  const original = fileName(name), dest = path.join(downloadsDir, randomUUID() + '-' + original);
  if (Buffer.byteLength(original) > 180) throw new Error('Invalid file name.');
  if (Number(req.headers['content-length']) > MAX_UPLOAD) return json(res, 413, { error: 'Upload too large (100 MB limit).' });
  await mkdir(downloadsDir, { recursive: true, mode: 0o700 });
  let bytes = 0;
  const limit = new Transform({ transform(chunk, _, callback) { bytes += chunk.length; callback(bytes > MAX_UPLOAD ? new Error('Upload too large (100 MB limit).') : null, chunk); } });
  try {
    await pipeline(req, limit, createWriteStream(dest, { flags: 'wx', mode: 0o600 }));
    return json(res, 201, { name: path.basename(dest), bytes });
  } catch (error) { await rm(dest, { force: true }); if (error.message.startsWith('Upload too')) return json(res, 413, { error: error.message }); throw error; }
}
async function sendFile(res, filepath, filename) {
  if (filepath.startsWith(browserHome + path.sep)) await requireEncryptedHome();
  const file = await open(filepath, constants.O_RDONLY | constants.O_NOFOLLOW).catch(() => null);
  if (!file) return json(res, 404, { error: 'File not found.' });
  const info = await file.stat();
  if (!info.isFile()) { await file.close(); return json(res, 404, { error: 'File not found.' }); }
  const fallback = filename.replace(/["\\\r\n]/g, '_').replace(/[^\x20-\x7e]/g, '_');
  const disposition = ['attachment; filename="', fallback, '"; filename*=UTF-8', "''", encodeURIComponent(filename)].join('');
  headers(res, 200, { 'Content-Type': 'application/octet-stream', 'Content-Length': info.size, 'Content-Disposition': disposition });
  createReadStream(filepath, { fd: file.fd, autoClose: true }).pipe(res);
}
function webAddress(input) {
  const u = new URL(input);
  if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password) throw new Error('Only HTTP and HTTPS bookmarks are allowed.');
  return u.href;
}

async function handle(req, res) {
  if (!hostOkay(req)) return json(res, 403, { error: 'Invalid host.' });
  const url = new URL(req.url, config.origin);
  if (req.method === 'GET' && url.pathname === '/login') {
    if (authenticated(req, config, store.state.sessionEpoch)) { headers(res, 302, { Location: '/' }); return res.end(); }
    return asset(res, '../public/login.html', 'text/html; charset=utf-8');
  }
  if (req.method === 'GET' && url.pathname === '/login.js') return asset(res, '../public/login.js', 'text/javascript; charset=utf-8');
  if (req.method === 'POST' && url.pathname === '/api/login') {
    if (!originOkay(req)) return json(res, 403, { error: 'Invalid origin.' });
    const input = await body(req);
    if (!await verifyPassword(input.password, config, req.socket.remoteAddress || 'unknown')) return json(res, 401, { error: 'Incorrect password or too many attempts. Try again later.' });
    return json(res, 200, { ok: true }, { 'Set-Cookie': sessionCookie(newSession(config, store.state.sessionEpoch), config) });
  }
  if (!authenticated(req, config, store.state.sessionEpoch)) {
    if (req.method === 'GET' && !url.pathname.startsWith('/api/')) { headers(res, 302, { Location: '/login' }); return res.end(); }
    return json(res, 401, { error: 'Sign in required.' });
  }
  if (req.method !== 'GET' && req.method !== 'HEAD' && !originOkay(req)) return json(res, 403, { error: 'Invalid origin.' });
  if (isDesktop(url.pathname)) {
    if (url.pathname === '/desktop') { headers(res, 302, { Location: '/desktop/' }); return res.end(); }
    return desktop.web(req, res);
  }
  if (req.method === 'GET' && url.pathname === '/') return asset(res, '../public/index.html', 'text/html; charset=utf-8');
  if (req.method === 'GET' && url.pathname === '/app.js') return asset(res, '../public/app.js', 'text/javascript; charset=utf-8');
  if (req.method === 'GET' && url.pathname === '/style.css') return asset(res, '../public/style.css', 'text/css; charset=utf-8');
  if (req.method === 'GET' && url.pathname === '/api/state') return json(res, 200, store.publicState());
  if (req.method === 'POST' && url.pathname === '/api/logout') {
    await store.mutate(s => { s.sessionEpoch++; }); desktop.revokeAll();
    return json(res, 200, { ok: true }, { 'Set-Cookie': clearCookie(config) });
  }
  if (req.method === 'GET' && url.pathname === '/api/history') {
    const q = (url.searchParams.get('q') || '').toLowerCase().slice(0, 200);
    return json(res, 200, store.profile().history.filter(h => (h.title + ' ' + h.url).toLowerCase().includes(q)).slice(0, 200));
  }
  if (req.method === 'POST' && url.pathname === '/api/bookmarks') {
    const x = await body(req), target = webAddress(x.url);
    await store.mutate(() => { const p = store.profile(), i = p.bookmarks.findIndex(b => b.url === target);
      if (i >= 0) p.bookmarks.splice(i, 1); else p.bookmarks.unshift({ id: randomUUID(), url: target, title: String(x.title || target).slice(0, 180), at: Date.now() }); });
    return json(res, 200, { ok: true });
  }
  if (req.method === 'POST' && url.pathname === '/api/notes') {
    const x = await body(req), value = String(x.text || '').slice(0, 20_000);
    if (!value.trim()) throw new Error('Note cannot be empty.');
    await store.mutate(() => store.profile().notes.unshift({ id: randomUUID(), url: String(x.url || '').slice(0, 4096), text: value, at: Date.now() }));
    return json(res, 200, { ok: true });
  }
  const note = url.pathname.match(/^\/api\/notes\/([a-f0-9-]+)$/);
  if (note && req.method === 'DELETE') { await store.mutate(() => { const p = store.profile(); p.notes = p.notes.filter(n => n.id !== note[1]); }); return json(res, 200, { ok: true }); }
  if (req.method === 'GET' && url.pathname === '/api/files') return json(res, 200, await listFiles());
  if (req.method === 'POST' && url.pathname === '/api/files') return upload(req, res, url.searchParams.get('name'));
  const file = url.pathname.match(/^\/api\/files\/([^/]+)$/);
  if (file) {
    const name = fileName(decodeURIComponent(file[1])), target = path.join(downloadsDir, name);
    if (req.method === 'GET') return sendFile(res, target, name);
    if (req.method === 'DELETE') { await requireEncryptedHome(); await unlink(target).catch(e => { if (e.code !== 'ENOENT') throw e; }); return json(res, 200, { ok: true }); }
  }
  const legacy = url.pathname.match(/^\/api\/legacy-downloads\/([a-f0-9-]+)$/);
  if (legacy && req.method === 'GET') {
    const item = store.state.downloads.find(d => d.id === legacy[1]);
    if (!item) return json(res, 404, { error: 'File not found.' });
    const temp = path.join(runtimeDir, 'download-' + randomUUID());
    await secure.decryptFile('downloads/' + item.id + '.enc', temp);
    res.on('close', () => rm(temp, { force: true }).catch(() => {}));
    return sendFile(res, temp, item.name);
  }
  return json(res, 404, { error: 'Not found.' });
}

const server = http.createServer((req, res) => handle(req, res).catch(error => failure(res, error)));
server.on('upgrade', (req, socket, head) => {
  const pathname = (() => { try { return new URL(req.url, config.origin).pathname; } catch { return ''; } })();
  if (!pathname.startsWith('/desktop/') || !hostOkay(req) || !originOkay(req) || !authenticated(req, config, store.state.sessionEpoch)) {
    socket.end('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n'); return;
  }
  desktop.upgrade(req, socket, head);
});
server.listen(port, '0.0.0.0', () => console.log('Private browser gateway ready on port ' + port));
async function shutdown() { desktop.revokeAll(); server.close(); await store.pending; process.exit(); }
process.on('SIGTERM', () => shutdown().catch(() => process.exit(1)));
process.on('SIGINT', () => shutdown().catch(() => process.exit(1)));
