import http from 'node:http';

// The desktop service is reachable only on the private Compose network. Its
// HTTP and streaming WebSocket traffic must pass through the app's auth gate.
export class DesktopProxy {
  constructor(host = process.env.DESKTOP_HOST || 'chromium', port = Number(process.env.DESKTOP_PORT || 3000)) {
    this.host = host;
    this.port = port;
    this.sockets = new Set();
  }

  headers(req) {
    const headers = { ...req.headers, host: `${this.host}:${this.port}`, 'x-forwarded-host': req.headers.host, 'x-forwarded-proto': 'https' };
    if (headers.cookie) {
      headers.cookie = headers.cookie.split(';').map(x => x.trim()).filter(x => !x.startsWith('browser_session=')).join('; ');
      if (!headers.cookie) delete headers.cookie;
    }
    delete headers.authorization;
    return headers;
  }

  web(req, res) {
    const upstream = http.request({ host: this.host, port: this.port, method: req.method, path: req.url, headers: this.headers(req), timeout: 120_000 }, incoming => {
      res.writeHead(incoming.statusCode || 502, { ...incoming.headers, 'cache-control': 'no-store' });
      incoming.pipe(res);
    });
    upstream.on('timeout', () => upstream.destroy(new Error('Desktop timed out.')));
    upstream.on('error', () => { if (!res.headersSent) res.writeHead(502, { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store' }); res.end('Desktop unavailable. Check the encrypted profile mount and Chromium container.'); });
    req.on('aborted', () => upstream.destroy());
    res.on('close', () => upstream.destroy());
    req.pipe(upstream);
  }

  upgrade(req, socket, head) {
    const upstream = http.request({ host: this.host, port: this.port, method: 'GET', path: req.url, headers: this.headers(req), timeout: 30_000 });
    let connected = false;
    upstream.on('upgrade', (response, remote, remoteHead) => {
      connected = true;
      socket.write(`HTTP/1.1 101 Switching Protocols\r\n${Object.entries(response.headers).map(([key, value]) => `${key}: ${value}`).join('\r\n')}\r\n\r\n`);
      if (head.length) remote.write(head);
      if (remoteHead.length) socket.write(remoteHead);
      this.sockets.add(socket);
      const cleanup = () => { this.sockets.delete(socket); remote.destroy(); socket.destroy(); };
      socket.on('close', cleanup); remote.on('close', cleanup);
      socket.pipe(remote).pipe(socket);
    });
    upstream.on('response', response => { response.resume(); socket.end(`HTTP/1.1 ${response.statusCode} Rejected\r\nConnection: close\r\n\r\n`); });
    upstream.on('timeout', () => upstream.destroy(new Error('Desktop timed out.')));
    upstream.on('error', () => { if (!connected) socket.end('HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n'); else socket.destroy(); });
    socket.on('close', () => upstream.destroy());
    upstream.end();
  }

  revokeAll() { for (const socket of this.sockets) socket.destroy(); this.sockets.clear(); }
}
