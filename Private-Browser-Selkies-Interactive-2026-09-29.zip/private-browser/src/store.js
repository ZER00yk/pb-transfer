import { randomUUID } from 'node:crypto';

const initial = () => {
  const id = randomUUID();
  return {
    version: 1, sessionEpoch: 0, activeProfileId: id,
    profiles: [{ id, name: 'Main', tabs: [], activeTabId: null, bookmarks: [], history: [], notes: [], createdAt: Date.now() }],
    downloads: [], preferences: { quality: 72, fps: 10 }
  };
};

export class Store {
  constructor(secure) { this.secure = secure; this.state = null; this.pending = Promise.resolve(); }
  async init() {
    try { this.state = JSON.parse((await this.secure.read('state.enc')).toString('utf8')); }
    catch (e) { if (e.code !== 'ENOENT') throw e; this.state = initial(); await this.save(); }
    if (this.state.version !== 1) throw new Error('Unsupported saved state version.');
  }
  async save() { await this.secure.write('state.enc', Buffer.from(JSON.stringify(this.state))); }
  async mutate(fn) {
    const task = this.pending.then(async () => { const result = fn(this.state); await this.save(); return result; });
    this.pending = task.catch(() => {});
    return task;
  }
  profile(id = this.state.activeProfileId) { return this.state.profiles.find(p => p.id === id); }
  publicState() {
    const { sessionEpoch, ...safe } = this.state;
    return {
      ...safe,
      profiles: safe.profiles.map(profile => ({
        ...profile,
        tabs: profile.tabs.map(({ session, ...tab }) => tab)
      }))
    };
  }
}
