import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { createReadStream, createWriteStream } from 'node:fs';
import { mkdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises';
import { pipeline } from 'node:stream/promises';
import path from 'node:path';

const MAGIC = Buffer.from('PB01');
const HEADER = 16;
const TAG = 16;

export class SecureData {
  constructor(key, root, runtime) {
    if (key.length !== 32) throw new Error('MASTER_KEY must be 32 bytes.');
    this.key = key; this.root = root; this.runtime = runtime;
  }
  async init() { await mkdir(this.root, { recursive: true, mode: 0o700 }); await mkdir(this.runtime, { recursive: true, mode: 0o700 }); }
  file(name) { return path.join(this.root, name); }
  async write(name, plain) {
    const iv = randomBytes(12);
    const cipher = createCipheriv('aes-256-gcm', this.key, iv);
    const ciphertext = Buffer.concat([cipher.update(plain), cipher.final()]);
    const out = Buffer.concat([MAGIC, iv, ciphertext, cipher.getAuthTag()]);
    const target = this.file(name), tmp = `${target}.${randomBytes(6).toString('hex')}.tmp`;
    await mkdir(path.dirname(target), { recursive: true, mode: 0o700 });
    await writeFile(tmp, out, { mode: 0o600 });
    await rename(tmp, target);
  }
  async read(name) {
    const input = await readFile(this.file(name));
    if (input.length < HEADER + TAG || !input.subarray(0, 4).equals(MAGIC)) throw new Error('Invalid encrypted file.');
    const decipher = createDecipheriv('aes-256-gcm', this.key, input.subarray(4, HEADER));
    decipher.setAuthTag(input.subarray(input.length - TAG));
    return Buffer.concat([decipher.update(input.subarray(HEADER, -TAG)), decipher.final()]);
  }
  async encryptFile(source, name) {
    const target = this.file(name), tmp = `${target}.${randomBytes(6).toString('hex')}.tmp`;
    await mkdir(path.dirname(target), { recursive: true, mode: 0o700 });
    const iv = randomBytes(12), cipher = createCipheriv('aes-256-gcm', this.key, iv);
    const out = createWriteStream(tmp, { mode: 0o600 });
    try {
      await new Promise((resolve, reject) => out.write(Buffer.concat([MAGIC, iv]), e => e ? reject(e) : resolve()));
      await pipeline(createReadStream(source), cipher, out);
      await (await import('node:fs/promises')).appendFile(tmp, cipher.getAuthTag());
      await rename(tmp, target);
    } catch (e) { await rm(tmp, { force: true }); throw e; }
  }
  async decryptFile(name, destination) {
    const source = this.file(name), info = await stat(source);
    if (info.size < HEADER + TAG) throw new Error('Invalid encrypted file.');
    const fd = await (await import('node:fs/promises')).open(source, 'r');
    const header = Buffer.alloc(HEADER), tag = Buffer.alloc(TAG);
    try { await fd.read(header, 0, HEADER, 0); await fd.read(tag, 0, TAG, info.size - TAG); } finally { await fd.close(); }
    if (!header.subarray(0, 4).equals(MAGIC)) throw new Error('Invalid encrypted file.');
    const decipher = createDecipheriv('aes-256-gcm', this.key, header.subarray(4));
    decipher.setAuthTag(tag);
    if (info.size === HEADER + TAG) {
      decipher.final();
      await writeFile(destination, Buffer.alloc(0), { mode: 0o600 });
      return;
    }
    try {
      await pipeline(createReadStream(source, { start: HEADER, end: info.size - TAG - 1 }), decipher, createWriteStream(destination, { mode: 0o600 }));
    } catch (e) { await rm(destination, { force: true }); throw e; }
  }
}
