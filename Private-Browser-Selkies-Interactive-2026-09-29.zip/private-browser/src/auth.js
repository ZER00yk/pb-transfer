import { createHmac, randomBytes, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
const scrypt = promisify(scryptCallback);
const attempts = new Map();

export function authConfig(env) {
  const key = Buffer.from(env.MASTER_KEY || '', 'base64');
  const salt = Buffer.from(env.OWNER_PASSWORD_SALT || '', 'base64');
  const hash = Buffer.from(env.OWNER_PASSWORD_HASH || '', 'base64');
  if (key.length !== 32 || salt.length !== 32 || hash.length !== 64) throw new Error('Run npm run setup to create a valid .env.');
  const origin = new URL(env.APP_ORIGIN || '');
  if ((origin.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(origin.hostname)) || origin.pathname !== '/' || origin.search || origin.hash) throw new Error('APP_ORIGIN must be an HTTPS origin (localhost HTTP is allowed).');
  return { key, salt, hash, origin };
}
export async function verifyPassword(password, config, ip) {
  const now = Date.now();
  const record = attempts.get(ip) || { count: 0, until: 0 };
  if (record.until > now) return false;
  const candidate = await scrypt(String(password).slice(0, 1024), config.salt, 64, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
  const okay = timingSafeEqual(candidate, config.hash);
  if (okay) attempts.delete(ip);
  else { record.count++; if (record.count >= 5) { record.until = now + 15 * 60_000; record.count = 0; } attempts.set(ip, record); }
  return okay;
}
const sign = (payload, key) => createHmac('sha256', key).update(payload).digest('base64url');
export function newSession(config, epoch) {
  const payload = Buffer.from(JSON.stringify({ epoch, exp: Date.now() + 30 * 86400_000, nonce: randomBytes(24).toString('base64url') })).toString('base64url');
  return `${payload}.${sign(payload, config.key)}`;
}
export function authenticated(req, config, epoch) {
  const cookie = req.headers.cookie?.match(/(?:^|;\s*)browser_session=([^;]+)/)?.[1];
  if (!cookie || cookie.length > 512) return false;
  const [payload, mac, extra] = cookie.split('.');
  if (!payload || !mac || extra || mac.length !== 43) return false;
  const expected = sign(payload, config.key);
  if (!timingSafeEqual(Buffer.from(mac), Buffer.from(expected))) return false;
  try { const data = JSON.parse(Buffer.from(payload, 'base64url')); return data.epoch === epoch && Number.isFinite(data.exp) && data.exp > Date.now(); } catch { return false; }
}
export function sessionCookie(token, config) { return `browser_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000${config.origin.protocol === 'https:' ? '; Secure' : ''}`; }
export function clearCookie(config) { return `browser_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${config.origin.protocol === 'https:' ? '; Secure' : ''}`; }
