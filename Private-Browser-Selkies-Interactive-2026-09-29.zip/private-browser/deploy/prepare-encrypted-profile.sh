#!/usr/bin/env bash
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then echo 'Run with sudo or as root.' >&2; exit 1; fi
image=/var/lib/private-browser/chromium.luks
mountdir=/srv/private-browser/chromium
mapper=private-browser-chromium
if ! command -v cryptsetup >/dev/null; then apt-get update && apt-get install -y cryptsetup; fi
mkdir -p "$(dirname "$image")" "$mountdir"
created=0
if [ ! -e "$image" ]; then
  echo 'Creating a new 12 GB encrypted Chromium profile. Choose a passphrase and keep it safe.'
  truncate -s 12G "$image"
  chmod 600 "$image"
  if ! cryptsetup luksFormat --type luks2 --pbkdf argon2id "$image"; then rm -f "$image"; exit 1; fi
  created=1
fi
if ! cryptsetup isLuks "$image"; then echo 'Existing profile file is not LUKS; stopping without overwriting it.' >&2; exit 1; fi
if ! cryptsetup status "$mapper" >/dev/null 2>&1; then cryptsetup open "$image" "$mapper"; fi
if [ "$created" -eq 1 ]; then mkfs.ext4 -F -L private-browser "/dev/mapper/$mapper"; fi
if ! mountpoint -q "$mountdir"; then mount -o noatime,nodev,nosuid "/dev/mapper/$mapper" "$mountdir"; fi
chown 1000:1000 "$mountdir"
chmod 700 "$mountdir"
touch "$mountdir/.private-browser-encrypted"
chown 1000:1000 "$mountdir/.private-browser-encrypted"
chmod 600 "$mountdir/.private-browser-encrypted"
echo "Encrypted profile mounted at $mountdir. The passphrase is needed to unlock it after VPS reboots."
