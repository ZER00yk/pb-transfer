#!/usr/bin/env bash
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then echo 'Run with sudo or as root on the OVH VPS.' >&2; exit 1; fi
cd "$(dirname "$0")/.."
newdir=$PWD
if ! docker compose version >/dev/null 2>&1; then echo 'Docker Compose is required.' >&2; exit 1; fi
mapfile -t candidates < <(docker ps -a --filter label=com.docker.compose.service=browser --format '{{.ID}}')
if [ "${#candidates[@]}" -ne 1 ]; then echo 'Expected exactly one existing browser service container. Inspect docker ps -a before changing anything.' >&2; exit 1; fi
old_id=${candidates[0]}
old_dir=$(docker inspect -f '{{index .Config.Labels "com.docker.compose.project.working_dir"}}' "$old_id")
project=$(docker inspect -f '{{index .Config.Labels "com.docker.compose.project"}}' "$old_id")
data_source=$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/data"}}{{.Source}}{{end}}{{end}}' "$old_id")
if [ -z "$old_dir" ] || [ -z "$project" ] || [ -z "$data_source" ] || [ "$newdir" = "$old_dir" ] || [ ! -f "$old_dir/.env" ]; then
  echo 'Existing deployment could not be identified safely. Keep this release in a new directory and preserve the old one.' >&2; exit 1
fi
if [ "$(sed -n 's/^APP_ORIGIN=//p' "$old_dir/.env" | head -1)" != 'https://15-204-116-93.sslip.io' ]; then
  echo 'The existing APP_ORIGIN differs from the requested HTTPS domain. Stop and inspect it before installing.' >&2; exit 1
fi
if [ -e .env ]; then echo 'A .env already exists in this new release; stopping rather than overwriting secrets.' >&2; exit 1; fi
old_bytes=$(du -sb "$data_source" | cut -f1)
free_bytes=$(df -B1 --output=avail /var/lib | tail -1 | tr -d ' ')
if [ "$free_bytes" -lt "$((old_bytes + 3 * 1024 * 1024 * 1024))" ]; then
  echo 'Less than the old data size plus 3 GB of disk is free. Back up or expand the VPS disk before installing.' >&2; exit 1
fi
bash deploy/prepare-encrypted-profile.sh
install -m 600 "$old_dir/.env" .env
printf '%s\n' "$project" > .project-name
chmod 600 .project-name
backup=/var/lib/private-browser/backups/$(date -u +%Y%m%dT%H%M%SZ)
mkdir -p "$backup"
install -m 600 .env "$backup/owner.env"
printf '%s\n%s\n' "$old_dir" "$project" > "$backup/rollback-info"
printf '%s\n' "$backup" > .last-backup
echo 'Stopping the old browser to make a consistent encrypted-data backup.'
docker stop --time 120 "$old_id" >/dev/null
rollback() {
  echo 'Install failed. Restoring the previous deployment.' >&2
  docker compose -p "$project" -f "$newdir/compose.yaml" down --remove-orphans || true
  (cd "$old_dir" && docker compose -p "$project" up -d --build) || true
}
trap rollback ERR
tar -C "$data_source" -czf "$backup/old-encrypted-data.tgz" .
docker compose -p "$project" -f compose.yaml config --quiet
docker compose -p "$project" -f compose.yaml build --pull
docker compose -p "$project" -f compose.yaml run --rm --no-deps browser node deploy/migrate-profile.mjs
docker compose -p "$project" -f compose.yaml up -d --remove-orphans
chromium_id=$(docker compose -p "$project" -f compose.yaml ps -q chromium)
ready=0
for attempt in $(seq 1 60); do
  if docker exec "$chromium_id" pgrep -x chromium >/dev/null 2>&1; then ready=1; break; fi
  sleep 2
done
if [ "$ready" -ne 1 ]; then docker compose -p "$project" -f compose.yaml logs --tail=40 chromium; false; fi
if docker exec "$chromium_id" ps -ww -eo args | grep -q -- '--no-sandbox'; then
  echo 'Chromium unexpectedly started without its sandbox; restoring the old deployment.' >&2
  false
fi
trap - ERR
echo 'New interactive Chromium is running. Caddy stays on 127.0.0.1:3000.'
echo "Backup: $backup"
echo 'Open https://15-204-116-93.sslip.io/ and sign in. After a reboot, run sudo bash deploy/unlock-vps.sh here.'
