#!/usr/bin/env bash
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then echo 'Run with sudo or as root.' >&2; exit 1; fi
cd "$(dirname "$0")/.."
if [ ! -f .last-backup ]; then echo 'No recorded installation backup.' >&2; exit 1; fi
backup=$(cat .last-backup)
mapfile -t info < "$backup/rollback-info"
old_dir=${info[0]}
project=${info[1]}
if [ ! -f "$old_dir/compose.yaml" ] || [ ! -f "$old_dir/.env" ]; then echo 'Original source or credentials missing; stopping.' >&2; exit 1; fi
docker compose -p "$project" -f compose.yaml down --remove-orphans
(cd "$old_dir" && docker compose -p "$project" up -d --build)
echo 'Previous browser is running. The new encrypted Chromium profile remains intact for a later retry.'
