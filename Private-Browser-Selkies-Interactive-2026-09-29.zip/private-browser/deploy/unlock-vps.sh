#!/usr/bin/env bash
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then echo 'Run with sudo or as root.' >&2; exit 1; fi
cd "$(dirname "$0")/.."
if [ ! -f .project-name ]; then echo 'Run install-vps.sh first.' >&2; exit 1; fi
project=$(cat .project-name)
bash deploy/prepare-encrypted-profile.sh
docker compose -p "$project" -f compose.yaml up -d --force-recreate browser chromium
echo 'Browser profile unlocked. Your HTTPS address should be available shortly.'
