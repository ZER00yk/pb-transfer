import { access, mkdir, readdir, rename, rm, writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { execFile as run } from 'node:child_process';
import { promisify } from 'node:util';
import path from 'node:path';
import { SecureData } from '../src/secure-data.js';
import { Store } from '../src/store.js';

const exec = promisify(run);
const home = process.env.BROWSER_HOME || '/chromium-home';
const data = process.env.DATA_DIR || '/data';
const runtime = process.env.RUNTIME_DIR || '/runtime';
await access(path.join(home, '.private-browser-encrypted'));
const key = Buffer.from(process.env.MASTER_KEY || '', 'base64');
const secure = new SecureData(key, data, runtime); await secure.init();
const store = new Store(secure); await store.init();
const profile = store.profile(process.argv[2] || store.state.activeProfileId);
if (!profile) throw new Error('Previous profile not found.');
const target = path.join(home, '.config/chromium');
const html = value => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
await mkdir(path.join(home, 'Downloads'), { recursive: true, mode: 0o700 });
const lines = profile.bookmarks.map(b => '<DT><A HREF="' + html(b.url) + '" ADD_DATE="' + Math.floor(b.at / 1000) + '">' + html(b.title) + '</A>');
await writeFile(path.join(home, 'Downloads', 'Previous browser bookmarks.html'), '<!DOCTYPE NETSCAPE-Bookmark-file-1>\n<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">\n<TITLE>Bookmarks</TITLE>\n<H1>Bookmarks</H1>\n<DL><p>\n' + lines.join('\n') + '\n</DL><p>\n', { mode: 0o600 });
try { await access(path.join(target, 'Default')); console.log('Existing Chromium profile found; leaving it unchanged.'); process.exit(0); } catch {}
const staging = path.join(home, '.migration-' + randomUUID());
const archive = path.join(staging, 'previous.tgz');
await mkdir(staging, { recursive: true, mode: 0o700 });
try {
  await secure.decryptFile('profiles/' + profile.id + '.enc', archive);
  const listing = (await exec('tar', ['-tzf', archive], { maxBuffer: 20 * 1024 * 1024 })).stdout.trim().split('\n');
  const prefix = 'profile-' + profile.id + '/';
  if (!listing.every(name => name === 'profile-' + profile.id || name.startsWith(prefix) && !name.split('/').includes('..'))) throw new Error('Unexpected path in previous profile archive.');
  await exec('tar', ['-xzf', archive, '-C', staging, '--no-same-owner']);
  await rm(archive);
  await mkdir(path.dirname(target), { recursive: true });
  await rename(path.join(staging, 'profile-' + profile.id), target);
  for (const name of await readdir(target)) if (name.startsWith('Singleton')) await rm(path.join(target, name), { force: true });
  console.log('Copied previous Chromium user-data directory into the encrypted volume. Website sessions may require one manual login.');
} catch (error) {
  if (error.code === 'ENOENT') console.log('No prior profile archive found; Chromium will create a fresh profile. Saved lists and encrypted downloads remain available in the app.');
  else throw error;
} finally { await rm(staging, { recursive: true, force: true }); }
