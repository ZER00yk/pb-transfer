import { createInterface } from 'node:readline';
import { randomBytes, scrypt as scryptCallback } from 'node:crypto';
import { promisify } from 'node:util';
import { writeFile, access } from 'node:fs/promises';
const scrypt = promisify(scryptCallback);
try { await access('.env'); console.error('.env already exists. Move it aside before creating new keys; old encrypted data needs the old MASTER_KEY.'); process.exit(1); } catch (e) { if (e.code !== 'ENOENT') throw e; }
if (!process.stdin.isTTY) { console.error('Run npm run setup in an interactive terminal.'); process.exit(1); }
const rl = createInterface({ input: process.stdin, output: process.stdout, terminal: true });
const ask = q => new Promise(resolve => rl.question(q, resolve));
const origin = (await ask('Exact app URL (e.g. https://browser.your-tailnet.ts.net): ')).trim();
const u = new URL(origin);
if ((u.protocol !== 'https:' && u.hostname !== 'localhost' && u.hostname !== '127.0.0.1') || u.pathname !== '/' || u.search || u.hash) throw new Error('Use an HTTPS origin (localhost HTTP is allowed), with no path.');
rl._writeToOutput = function (value) { if (!this.stdoutMuted) this.output.write(value); };
rl.output.write('Owner password (at least 16 characters): ');
rl.stdoutMuted = true;
const pass = await ask('');
rl.output.write('\n');
rl.output.write('Repeat password: ');
const again = await ask('');
rl.output.write('\n');
rl.stdoutMuted = false;
rl.close();
if (pass !== again || pass.length < 16 || pass.length > 1024) throw new Error('Passwords must match and contain 16–1024 characters.');
const salt = randomBytes(32);
const hash = await scrypt(pass, salt, 64, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
const body = `APP_ORIGIN=${u.origin}\nMASTER_KEY=${randomBytes(32).toString('base64')}\nOWNER_PASSWORD_SALT=${salt.toString('base64')}\nOWNER_PASSWORD_HASH=${hash.toString('base64')}\n`;
await writeFile('.env', body, { mode: 0o600, flag: 'wx' });
console.log('Created .env. Keep this file backed up securely; losing MASTER_KEY makes saved data unreadable.');
