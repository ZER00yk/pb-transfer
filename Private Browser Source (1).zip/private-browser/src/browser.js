import { chromium } from 'playwright';
import { randomUUID } from 'node:crypto';
import { lookup } from 'node:dns/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdir, rm, access } from 'node:fs/promises';
import path from 'node:path';
import { isIP } from 'node:net';

const exec = promisify(execFile);
const clamp = (v, min, max) => Math.max(min, Math.min(max, Number(v) || min));
const forbiddenIPv4 = ip => {
  const [a, b] = ip.split('.').map(Number);
  return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) ||
    (a === 100 && b >= 64 && b <= 127) || (a === 192 && b === 0) ||
    (a === 198 && (b === 18 || b === 19));
};
const forbiddenIP = ip => {
  if (isIP(ip) === 4) return forbiddenIPv4(ip);
  if (isIP(ip) === 6) {
    const x = ip.toLowerCase();
    if (x.startsWith('::ffff:')) {
      const tail = x.slice(7);
      if (tail.includes('.')) return forbiddenIPv4(tail);
      const [high, low] = tail.split(':').map(part => parseInt(part, 16));
      if (Number.isFinite(high) && Number.isFinite(low)) return forbiddenIPv4(`${high >> 8}.${high & 255}.${low >> 8}.${low & 255}`);
      return true;
    }
    return x === '::' || x === '::1' || x.startsWith('fc') || x.startsWith('fd') || x.startsWith('fe8') || x.startsWith('fe9') || x.startsWith('fea') || x.startsWith('feb') || x.startsWith('ff');
  }
  return true;
};
const dnsCache = new Map();
export async function safeUrl(input) {
  if (typeof input !== 'string' || input.length > 4096) throw new Error('Enter a valid web address.');
  const raw = input.trim();
  const url = new URL(/^[a-z][a-z0-9+.-]*:/i.test(raw) ? raw : `https://${raw}`);
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new Error('Only public HTTP and HTTPS addresses are allowed.');
  const host = url.hostname.replace(/^\[|\]$/g, '').toLowerCase();
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || host.endsWith('.internal') || !host.includes('.') && !isIP(host)) throw new Error('Local and private addresses are blocked.');
  const cached = dnsCache.get(host);
  let addresses;
  if (cached && cached.until > Date.now()) addresses = cached.addresses;
  else { addresses = (await lookup(host, { all: true, verbatim: true })).map(x => x.address); dnsCache.set(host, { addresses, until: Date.now() + 15_000 }); }
  if (!addresses.length || addresses.some(forbiddenIP)) throw new Error('Local and private addresses are blocked.');
  return url.href;
}

export class BrowserManager {
  constructor(store, secure, onChange) {
    this.store = store; this.secure = secure; this.onChange = onChange;
    this.context = null; this.pages = new Map(); this.profileId = null;
    this.viewport = { width: 1150, height: 720 }; this.busy = Promise.resolve();
  }
  serial(fn) { const next = this.busy.then(fn); this.busy = next.catch(() => {}); return next; }
  async ensure() { return this.serial(() => this.open()); }
  async open() {
    if (this.context) return;
    const profile = this.store.profile();
    if (!profile) throw new Error('No active profile.');
    const id = profile.id, dir = path.join(this.secure.runtime, `profile-${id}`);
    await mkdir(dir, { recursive: true, mode: 0o700 });
    const archive = `profiles/${id}.enc`;
    try {
      await access(this.secure.file(archive));
      const temp = path.join(this.secure.runtime, `restore-${id}.tgz`);
      try { await this.secure.decryptFile(archive, temp); await exec('tar', ['-xzf', temp, '-C', this.secure.runtime]); }
      finally { await rm(temp, { force: true }); }
    } catch (e) { if (e.code !== 'ENOENT') throw e; }
    this.context = await chromium.launchPersistentContext(dir, {
      headless: true, viewport: this.viewport, acceptDownloads: true, hasTouch: true,
      args: ['--enable-webgl', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader']
    });
    this.profileId = id;
    await this.context.route('**/*', async route => {
      try { await safeUrl(route.request().url()); await route.continue(); }
      catch { await route.abort('blockedbyclient').catch(() => {}); }
    });
    const initial = this.context.pages();
    let reused = false;
    for (const tab of profile.tabs) {
      const page = !reused && initial.length ? initial[0] : await this.context.newPage();
      reused = true;
      this.attach(page, tab.id);
      if (/^https?:/.test(tab.url)) await page.goto(tab.url, { waitUntil: 'domcontentloaded', timeout: 20_000 }).catch(() => {});
    }
    if (!profile.tabs.length) {
      const tab = { id: randomUUID(), url: 'about:blank', title: 'New tab' };
      await this.store.mutate(() => { profile.tabs.push(tab); profile.activeTabId = tab.id; });
      this.attach(initial[0] || await this.context.newPage(), tab.id);
      reused = true;
    }
    for (const page of initial.slice(reused ? 1 : 0)) await page.close().catch(() => {});
    if (!profile.tabs.some(t => t.id === profile.activeTabId)) profile.activeTabId = profile.tabs[0]?.id;
    this.onChange();
  }
  attach(page, id) {
    this.pages.set(id, page);
    page.on('framenavigated', frame => {
      if (frame !== page.mainFrame() || this.profileId !== this.store.state.activeProfileId) return;
      const url = frame.url();
      this.store.mutate(() => {
        const profile = this.store.profile(), tab = profile?.tabs.find(t => t.id === id);
        if (!tab) return;
        tab.url = url;
        if (/^https?:/.test(url)) {
          profile.history.unshift({ id: randomUUID(), url, title: tab.title || url, at: Date.now() });
          profile.history.length = Math.min(profile.history.length, 3000);
        }
      }).then(() => this.onChange()).catch(() => {});
      page.title().then(title => this.updateTitle(id, title)).catch(() => {});
    });
    page.on('load', () => page.title().then(title => this.updateTitle(id, title)).catch(() => {}));
    page.on('popup', popup => this.addPopup(popup));
    page.on('download', download => this.saveDownload(download, id).catch(() => {}));
  }
  async updateTitle(id, title) {
    if (!title || this.profileId !== this.store.state.activeProfileId) return;
    await this.store.mutate(() => {
      const p = this.store.profile(), tab = p?.tabs.find(t => t.id === id);
      if (tab) { tab.title = title.slice(0, 180); const h = p.history.find(h => h.url === tab.url); if (h) h.title = tab.title; }
    });
    this.onChange();
  }
  async addPopup(page) {
    const id = randomUUID();
    await this.store.mutate(() => {
      const p = this.store.profile(); p.tabs.push({ id, url: page.url(), title: 'New tab' }); p.activeTabId = id;
    });
    this.attach(page, id); this.onChange();
  }
  activePage() { return this.pages.get(this.store.profile()?.activeTabId); }
  async newTab(url) {
    await this.ensure();
    const page = await this.context.newPage(), id = randomUUID();
    await this.store.mutate(() => { const p = this.store.profile(); p.tabs.push({ id, url: 'about:blank', title: 'New tab' }); p.activeTabId = id; });
    this.attach(page, id); this.onChange();
    if (url) await this.navigate(id, url);
    return id;
  }
  async activate(id) {
    await this.ensure();
    if (!this.pages.has(id)) throw new Error('Tab not found.');
    await this.store.mutate(() => { this.store.profile().activeTabId = id; });
    await this.pages.get(id).setViewportSize(this.viewport);
    this.onChange();
  }
  async closeTab(id) {
    await this.ensure();
    const page = this.pages.get(id); if (!page) throw new Error('Tab not found.');
    this.pages.delete(id);
    await page.close();
    await this.store.mutate(() => {
      const p = this.store.profile(); p.tabs = p.tabs.filter(t => t.id !== id);
      if (p.activeTabId === id) p.activeTabId = p.tabs.at(-1)?.id || null;
    });
    if (!this.store.profile().tabs.length) await this.newTab();
    this.onChange();
  }
  async navigate(id, input) {
    await this.ensure();
    const page = this.pages.get(id); if (!page) throw new Error('Tab not found.');
    const url = await safeUrl(input);
    await page.goto(url, { waitUntil: 'commit', timeout: 25_000 });
    this.onChange();
  }
  async action(id, command) {
    await this.ensure(); const page = this.pages.get(id);
    if (!page) throw new Error('Tab not found.');
    if (command === 'back') await page.goBack({ waitUntil: 'commit', timeout: 20_000 });
    else if (command === 'forward') await page.goForward({ waitUntil: 'commit', timeout: 20_000 });
    else if (command === 'reload') await page.reload({ waitUntil: 'commit', timeout: 20_000 });
    else throw new Error('Unknown action.');
    this.onChange();
  }
  async resize(width, height) {
    this.viewport = { width: clamp(width, 320, 1920), height: clamp(height, 350, 1200) };
    const page = this.activePage(); if (page && !page.isClosed()) await page.setViewportSize(this.viewport);
  }
  async screenshot() {
    const page = this.activePage(); if (!page || page.isClosed()) return null;
    return page.screenshot({ type: 'jpeg', quality: this.store.state.preferences.quality, timeout: 8000, animations: 'allow' });
  }
  async input(message) {
    const page = this.activePage(); if (!page || page.isClosed()) return;
    const x = clamp(message.x, 0, this.viewport.width), y = clamp(message.y, 0, this.viewport.height);
    if (message.kind === 'move') await page.mouse.move(x, y);
    else if (message.kind === 'down') await page.mouse.move(x, y).then(() => page.mouse.down({ button: ['left', 'right', 'middle'].includes(message.button) ? message.button : 'left' }));
    else if (message.kind === 'up') await page.mouse.move(x, y).then(() => page.mouse.up({ button: ['left', 'right', 'middle'].includes(message.button) ? message.button : 'left' }));
    else if (message.kind === 'tap') await page.touchscreen.tap(x, y);
    else if (message.kind === 'wheel') await page.mouse.wheel(clamp(message.dx, -1000, 1000), clamp(message.dy, -1000, 1000));
    else if (message.kind === 'keyDown' || message.kind === 'keyUp') {
      if (typeof message.key !== 'string' || message.key.length > 32) return;
      await page.keyboard[message.kind === 'keyDown' ? 'down' : 'up'](message.key).catch(() => {});
    } else if (message.kind === 'text' && typeof message.text === 'string') await page.keyboard.insertText(message.text.slice(0, 4096));
  }
  async saveDownload(download, tabId) {
    const id = randomUUID(), source = path.join(this.secure.runtime, `download-${id}`);
    try {
      await download.saveAs(source);
      await this.secure.encryptFile(source, `downloads/${id}.enc`);
      const name = download.suggestedFilename().replace(/[\r\n\\/]/g, '_').slice(0, 200) || 'download';
      await this.store.mutate(() => this.store.state.downloads.unshift({ id, profileId: this.profileId, tabId, name, at: Date.now() }));
      this.onChange();
    } finally { await rm(source, { force: true }); }
  }
  async switchProfile(id) {
    return this.serial(async () => {
      if (!this.store.state.profiles.some(p => p.id === id)) throw new Error('Profile not found.');
      await this.closeAndSave();
      await this.store.mutate(() => { this.store.state.activeProfileId = id; });
      await this.open(); this.onChange();
    });
  }
  async checkpoint() { return this.serial(() => this.closeAndSave()); }
  async closeAndSave() {
    if (!this.context) return;
    const id = this.profileId, dir = path.join(this.secure.runtime, `profile-${id}`);
    const context = this.context;
    this.context = null; this.pages.clear(); this.profileId = null;
    await context.close();
    const archive = path.join(this.secure.runtime, `checkpoint-${id}.tgz`);
    try {
      await exec('tar', ['--exclude=Cache', '--exclude=Code Cache', '--exclude=GPUCache', '--exclude=ShaderCache', '--exclude=Crashpad', '--exclude=Singleton*', '-czf', archive, '-C', this.secure.runtime, `profile-${id}`], { maxBuffer: 1024 * 1024 });
      await this.secure.encryptFile(archive, `profiles/${id}.enc`);
    } finally { await rm(archive, { force: true }); await rm(dir, { recursive: true, force: true }); }
  }
}
