import http from 'node:http';
import { readFile, rm, stat } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { randomUUID } from 'node:crypto';
import path from 'node:path';
import { statfs } from 'node:fs/promises';
import { WebSocketServer, WebSocket } from 'ws';
import { SecureData } from './secure-data.js';
import { Store } from './store.js';
import { BrowserManager, safeUrl } from './browser.js';
import { authConfig, verifyPassword, newSession, authenticated, sessionCookie, clearCookie } from './auth.js';

const config = authConfig(process.env);
const dataDir = process.env.DATA_DIR || path.resolve('private-data');
const runtimeDir = process.env.RUNTIME_DIR || '/dev/shm/private-browser';
const port = Number(process.env.PORT || 3000);
const secure = new SecureData(config.key, dataDir, runtimeDir); await secure.init();
const fsInfo = await statfs(runtimeDir);
if (process.env.NODE_ENV === 'production' && fsInfo.type !== 0x01021994) throw new Error('RUNTIME_DIR must be on tmpfs; decrypted profiles must stay in memory.');
const store = new Store(secure); await store.init();
const clients = new Set();
const send = (ws, obj) => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); };
const broadcast = () => { const state = { type: 'state', value: store.publicState() }; for (const ws of clients) send(ws, state); };
const browser = new BrowserManager(store, secure, broadcast);
let idleTimer = null;

function headers(res, status, extra = {}) {
  res.writeHead(status, {
    'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY',
    'Content-Security-Policy': "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; connect-src 'self' ws: wss:; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
    ...(config.origin.protocol === 'https:' ? { 'Strict-Transport-Security': 'max-age=31536000; includeSubDomains' } : {}), ...extra
  });
}
function json(res, status, value, extra = {}) { headers(res, status, { 'Content-Type': 'application/json; charset=utf-8', ...extra }); res.end(JSON.stringify(value)); }
function originOkay(req) { return req.headers.origin === config.origin.origin; }
function hostOkay(req) {
  return req.headers.host === config.origin.host;
}
async function body(req) {
  if (!req.headers['content-type']?.startsWith('application/json')) throw new Error('JSON request required.');
  let s = '';
  for await (const chunk of req) { s += chunk; if (s.length > 65_536) throw new Error('Request too large.'); }
  return JSON.parse(s || '{}');
}
async function asset(res, file, type) { headers(res, 200, { 'Content-Type': type }); res.end(await readFile(new URL(file, import.meta.url))); }
function failure(res, e) {
  if (res.headersSent) { res.end(); return; }
  const known = /^(Enter |Only |Local |Tab not|Profile not|Unknown |Request too|JSON request|Invalid |Note |Bookmark |Download |Name |No active)/.test(e.message);
  json(res, known ? 400 : 503, { error: known ? e.message : 'The browser is temporarily unavailable. Try again.' });
  if (!known) console.error('Request failed:', e.name || 'Error');
}
async function handle(req, res) {
  if (!hostOkay(req)) return json(res, 403, { error: 'Invalid host or transport.' });
  const url = new URL(req.url, config.origin);
  if (req.method === 'GET' && url.pathname === '/login') {
    if (authenticated(req, config, store.state.sessionEpoch)) { headers(res, 302, { Location: '/' }); return res.end(); }
    return asset(res, '../public/login.html', 'text/html; charset=utf-8');
  }
  if (req.method === 'GET' && url.pathname === '/login.js') return asset(res, '../public/login.js', 'text/javascript; charset=utf-8');
  if (req.method === 'POST' && url.pathname === '/api/login') {
    if (!originOkay(req)) return json(res, 403, { error: 'Invalid origin.' });
    const input = await body(req);
    const ip = req.socket.remoteAddress || 'unknown';
    if (!await verifyPassword(input.password, config, ip)) return json(res, 401, { error: 'Incorrect password or too many attempts. Try again later.' });
    const token = newSession(config, store.state.sessionEpoch);
    return json(res, 200, { ok: true }, { 'Set-Cookie': sessionCookie(token, config) });
  }
  if (!authenticated(req, config, store.state.sessionEpoch)) {
    if (req.method === 'GET' && !url.pathname.startsWith('/api/')) { headers(res, 302, { Location: '/login' }); return res.end(); }
    return json(res, 401, { error: 'Sign in required.' });
  }
  if (req.method !== 'GET' && !originOkay(req)) return json(res, 403, { error: 'Invalid origin.' });
  if (req.method === 'GET' && url.pathname === '/') return asset(res, '../public/index.html', 'text/html; charset=utf-8');
  if (req.method === 'GET' && url.pathname === '/app.js') return asset(res, '../public/app.js', 'text/javascript; charset=utf-8');
  if (req.method === 'GET' && url.pathname === '/style.css') return asset(res, '../public/style.css', 'text/css; charset=utf-8');
  if (req.method === 'GET' && url.pathname === '/api/state') { await browser.ensure(); return json(res, 200, store.publicState()); }
  if (req.method === 'POST' && url.pathname === '/api/logout') {
    await store.mutate(s => { s.sessionEpoch++; });
    for (const ws of clients) ws.close(1008, 'Signed out');
    await browser.checkpoint();
    return json(res, 200, { ok: true }, { 'Set-Cookie': clearCookie(config) });
  }
  if (req.method === 'POST' && url.pathname === '/api/tabs') { const x = await body(req); const id = await browser.newTab(x.url); return json(res, 200, { id }); }
  const tab = url.pathname.match(/^\/api\/tabs\/([a-f0-9-]+)(?:\/(activate|navigate|action))?$/);
  if (tab && req.method === 'POST') {
    const x = await body(req);
    if (tab[2] === 'activate') await browser.activate(tab[1]);
    else if (tab[2] === 'navigate') await browser.navigate(tab[1], x.url);
    else if (tab[2] === 'action') await browser.action(tab[1], x.command);
    else throw new Error('Unknown tab action.');
    return json(res, 200, { ok: true });
  }
  if (tab && req.method === 'DELETE' && !tab[2]) { await browser.closeTab(tab[1]); return json(res, 200, { ok: true }); }
  if (req.method === 'GET' && url.pathname === '/api/history') {
    const q = (url.searchParams.get('q') || '').toLowerCase().slice(0, 200);
    return json(res, 200, store.profile().history.filter(h => `${h.title} ${h.url}`.toLowerCase().includes(q)).slice(0, 200));
  }
  if (req.method === 'POST' && url.pathname === '/api/bookmarks') {
    const x = await body(req), target = await safeUrl(x.url);
    await store.mutate(() => {
      const p = store.profile(), i = p.bookmarks.findIndex(b => b.url === target);
      if (i >= 0) p.bookmarks.splice(i, 1);
      else p.bookmarks.unshift({ id: randomUUID(), url: target, title: String(x.title || target).slice(0, 180), at: Date.now() });
    }); broadcast(); return json(res, 200, { ok: true });
  }
  if (req.method === 'POST' && url.pathname === '/api/notes') {
    const x = await body(req), text = String(x.text || '').slice(0, 20_000);
    if (!text.trim()) throw new Error('Note cannot be empty.');
    await store.mutate(() => store.profile().notes.unshift({ id: randomUUID(), url: String(x.url || '').slice(0, 4096), text, at: Date.now() }));
    broadcast(); return json(res, 200, { ok: true });
  }
  const note = url.pathname.match(/^\/api\/notes\/([a-f0-9-]+)$/);
  if (note && req.method === 'DELETE') {
    await store.mutate(() => { const p = store.profile(); p.notes = p.notes.filter(n => n.id !== note[1]); });
    broadcast(); return json(res, 200, { ok: true });
  }
  if (req.method === 'POST' && url.pathname === '/api/profiles') {
    const x = await body(req), name = String(x.name || '').trim().slice(0, 40);
    if (!name) throw new Error('Name required.');
    const id = randomUUID();
    await store.mutate(s => { s.profiles.push({ id, name, tabs: [], activeTabId: null, bookmarks: [], history: [], notes: [], createdAt: Date.now() }); });
    await browser.switchProfile(id); return json(res, 200, { id });
  }
  const profile = url.pathname.match(/^\/api\/profiles\/([a-f0-9-]+)(?:\/(select|rename))?$/);
  if (profile && req.method === 'POST' && profile[2] === 'select') { await browser.switchProfile(profile[1]); return json(res, 200, { ok: true }); }
  if (profile && req.method === 'POST' && profile[2] === 'rename') {
    const x = await body(req), name = String(x.name || '').trim().slice(0, 40);
    if (!name) throw new Error('Name required.');
    await store.mutate(() => { const p = store.profile(profile[1]); if (!p) throw new Error('Profile not found.'); p.name = name; });
    broadcast(); return json(res, 200, { ok: true });
  }
  if (profile && req.method === 'DELETE' && !profile[2]) {
    if (profile[1] === store.state.activeProfileId || store.state.profiles.length === 1) throw new Error('Profile not found or currently active.');
    await store.mutate(s => { s.profiles = s.profiles.filter(p => p.id !== profile[1]); });
    await rm(secure.file(`profiles/${profile[1]}.enc`), { force: true });
    broadcast(); return json(res, 200, { ok: true });
  }
  if (req.method === 'POST' && url.pathname === '/api/preferences') {
    const x = await body(req);
    await store.mutate(s => {
      if (x.quality !== undefined) s.preferences.quality = Math.max(40, Math.min(90, Number(x.quality) || 72));
      if (x.fps !== undefined) s.preferences.fps = Math.max(2, Math.min(12, Number(x.fps) || 6));
    }); broadcast(); return json(res, 200, { ok: true });
  }
  if (req.method === 'POST' && url.pathname === '/api/save') { await browser.checkpoint(); await browser.ensure(); broadcast(); return json(res, 200, { ok: true }); }
  const download = url.pathname.match(/^\/api\/downloads\/([a-f0-9-]+)$/);
  if (download && req.method === 'GET') {
    const item = store.state.downloads.find(d => d.id === download[1]);
    if (!item) return json(res, 404, { error: 'Download not found.' });
    const temp = path.join(runtimeDir, `serve-${randomUUID()}`);
    await secure.decryptFile(`downloads/${item.id}.enc`, temp);
    const size = (await stat(temp)).size;
    const filename = item.name.replace(/["\\\r\n]/g, '_');
    const fallback = filename.replace(/[^\x20-\x7e]/g, '_');
    headers(res, 200, { 'Content-Type': 'application/octet-stream', 'Content-Length': size, 'Content-Disposition': `attachment; filename="${fallback}"; filename*=UTF-8''${encodeURIComponent(filename)}` });
    const stream = createReadStream(temp);
    stream.on('close', () => rm(temp, { force: true }).catch(() => {}));
    return stream.pipe(res);
  }
  return json(res, 404, { error: 'Not found.' });
}

const server = http.createServer((req, res) => handle(req, res).catch(e => failure(res, e)));
const wss = new WebSocketServer({ noServer: true, maxPayload: 65_536, perMessageDeflate: false });
server.on('upgrade', (req, socket, head) => {
  if (req.url !== '/ws' || !hostOkay(req) || !originOkay(req) || !authenticated(req, config, store.state.sessionEpoch)) {
    socket.end('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n'); return;
  }
  wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req));
});
wss.on('connection', ws => {
  if (idleTimer) { clearTimeout(idleTimer); idleTimer = null; }
  clients.add(ws); send(ws, { type: 'state', value: store.publicState() });
  browser.ensure().catch(e => send(ws, { type: 'error', message: `Browser unavailable: ${e.message}` }));
  ws.on('message', raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg.type === 'viewport') browser.resize(msg.width, msg.height).catch(() => {});
    else if (msg.type === 'input') browser.input(msg).catch(() => {});
  });
  ws.on('close', () => {
    clients.delete(ws);
    if (!clients.size) idleTimer = setTimeout(() => browser.checkpoint().catch(e => console.error('Profile checkpoint failed:', e)), 30_000);
  });
});
let frameBusy = false, lastFrame = 0;
async function sendFrame() {
  if (!clients.size || frameBusy || Date.now() - lastFrame < 1000 / store.state.preferences.fps) return;
  lastFrame = Date.now();
  frameBusy = true;
  try {
    const frame = await browser.screenshot();
    if (frame) for (const ws of clients) if (ws.readyState === WebSocket.OPEN && ws.bufferedAmount < 1_000_000) ws.send(frame, { binary: true });
  } catch {} finally { frameBusy = false; }
}
setInterval(() => sendFrame().catch(() => {}), 85);
server.listen(port, '0.0.0.0', () => console.log(`Private browser ready on port ${port}`));

let stopping = false;
async function shutdown() {
  if (stopping) return; stopping = true;
  for (const ws of clients) ws.close();
  server.close();
  try { await browser.checkpoint(); await store.pending; } catch (e) { console.error('Could not save profile:', e); process.exitCode = 1; }
  process.exit();
}
process.on('SIGTERM', shutdown); process.on('SIGINT', shutdown);
