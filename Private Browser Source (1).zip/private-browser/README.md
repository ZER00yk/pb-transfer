# Private Browser

A single-owner browser you can open from desktop or mobile. A server-side Playwright Chromium profile renders the page; the web app sends its image and your input over an authenticated WebSocket. The Password Game and PokéRogue are one-click shortcuts, and the address bar accepts other public sites.

## Features

- Owner password required for every page, API route, file download, and WebSocket. There is no public page-content proxy route or registration.
- Tabs, navigation, bookmarks, searchable history, notes, encrypted downloads, and multiple named profiles.
- Persistent Chromium cookies, local storage, IndexedDB, and login sessions inside each profile. Sign into sites once **inside this browser**; it does not import cookies from your existing Chrome or phone browser.
- AES-256-GCM encryption for saved state, downloads, and whole Chromium profile archives. Decrypted profiles and temporary downloads live in a RAM-backed tmpfs while the app runs.
- Responsive desktop/mobile controls, a text-entry tray, and arrow/Z/X/Enter/Escape controls for games.

## Private deployment with Docker and Tailscale

You need a Linux machine that can stay online, Docker Compose, and Tailscale on that machine and on each device you will use. The app is exposed only on the machine's loopback interface; Tailscale Serve gives it a private HTTPS address on your tailnet. Do not use Tailscale Funnel for this app.

1. Put this folder on the Linux machine. Start Tailscale Serve for port 3000 and note the exact `https://...ts.net` URL it displays:

   ```bash
   tailscale serve --bg http://127.0.0.1:3000
   tailscale serve status
   ```

2. In this folder, run `npm run setup`. Enter the exact HTTPS URL from the previous step and choose a password of at least 16 characters. The script writes a private `.env` with a salted password hash and an encryption key; it never stores the password itself.

3. Run `docker compose up -d --build`. The first build downloads Playwright Chromium and its Linux dependencies. Open your Tailscale HTTPS address from a desktop or mobile device on your tailnet, and sign in.

4. Back up both `.env` and the `browser_data` Docker volume in a secure place. The encryption key in `.env` is required to read the volume. To update the app after replacing its source, run `docker compose up -d --build` again.

The app checks the exact configured host and rejects cross-origin writes. The HTTPS URL must stay the same; if it changes, update `APP_ORIGIN` in `.env` and restart the container. The app binds only `127.0.0.1:3000` on the host. If another service already uses port 3000, change the host side of the Compose `ports` mapping and the Tailscale target, while leaving the container-side port 3000.

## Using the browser

- Click a shortcut or enter a URL. Use the bookmark star or the Library panel for bookmarks, history search, notes, and downloads.
- Desktop keyboard input goes to the remote page after you click its view. On mobile, tap the page and use **Keyboard** to type into a selected field; **Game controls** supplies directional and action keys. Full screen enlarges the view.
- The currently running Chromium process remains open while a device is connected. Thirty seconds after the last device disconnects, it closes and writes an encrypted profile checkpoint. **Save** makes a checkpoint immediately and reopens the saved tabs; this reloads any currently running game.
- Site sessions still obey each site's own expiration and security rules. A site can ask you to sign in again. The app transports video frames as images, so it does not relay page audio, webcam access, or browser extensions.

## Security and recovery notes

- Saved user data is encrypted on the persistent volume, but the key is present in the running app and the live profile is temporarily decrypted in RAM. Keep the machine and `.env` private, and use a host you trust.
- A power loss or forced process kill can lose changes since the last profile checkpoint. Use **Save** when you need a fresh checkpoint; normal Compose shutdown triggers one too.
- Local and private HTTP(S) destinations are blocked by the app's URL checks. For stronger protection against malicious websites, also deny the container outbound access to your LAN and cloud metadata addresses at the host firewall. The browser runs as an unprivileged container user with dropped Linux capabilities.
- Only one owner account exists. Signing out invalidates all app sessions. To change the owner password while keeping data, regenerate only `OWNER_PASSWORD_SALT` and `OWNER_PASSWORD_HASH`; preserve `MASTER_KEY`. Do not run setup over an existing `.env`.

## Development

With Node 22+ and an installed Playwright Chromium binary, run `npm install`, then `npm run setup` using `http://localhost:3000` as the origin, followed by `node --env-file=.env src/server.js`. For encrypted live profiles on Linux, the default runtime directory is `/dev/shm/private-browser`. Run `npm test` for the auth, encryption, and private-address checks.

This project does not provide a public demonstration account or a default password. Deployment needs your own always-on Linux host or VPS and your Tailscale account; the source package contains no credentials.
