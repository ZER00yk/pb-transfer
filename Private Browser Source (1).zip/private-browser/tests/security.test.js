import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes, scrypt as scryptCallback } from 'node:crypto';
import { promisify } from 'node:util';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import WebSocket from 'ws';
import { SecureData } from '../src/secure-data.js';
import { safeUrl } from '../src/browser.js';
const scrypt = promisify(scryptCallback);

test('encrypted records and files authenticate their contents', async () => {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'private-browser-test-'));
  const secure = new SecureData(randomBytes(32), path.join(dir, 'data'), path.join(dir, 'ram'));
  try {
    await secure.init();
    await secure.write('state.enc', Buffer.from('private note and cookie'));
    assert.equal((await secure.read('state.enc')).toString(), 'private note and cookie');
    assert.equal((await readFile(secure.file('state.enc'))).includes(Buffer.from('private note')), false);
    const source = path.join(dir, 'source'), output = path.join(dir, 'output');
    await writeFile(source, randomBytes(2_000_000));
    await secure.encryptFile(source, 'downloads/file.enc');
    await secure.decryptFile('downloads/file.enc', output);
    assert.deepEqual(await readFile(output), await readFile(source));
    await writeFile(source, Buffer.alloc(0));
    await secure.encryptFile(source, 'downloads/empty.enc');
    await secure.decryptFile('downloads/empty.enc', output);
    assert.equal((await readFile(output)).length, 0);
    const altered = await readFile(secure.file('state.enc')); altered[20] ^= 1;
    await writeFile(secure.file('state.enc'), altered);
    await assert.rejects(secure.read('state.enc'));
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('navigation rejects local addresses and non-web schemes', async () => {
  for (const value of ['file:///etc/passwd', 'http://127.0.0.1/', 'http://192.168.1.8/', 'http://localhost/', 'http://[::1]/', 'http://[::ffff:127.0.0.1]/', 'javascript:alert(1)']) {
    await assert.rejects(safeUrl(value), undefined, value);
  }
});

test('all app content and data require the owner session', async () => {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'private-browser-http-'));
  const port = await new Promise(resolve => { const s = net.createServer().listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => resolve(p)); }); });
  const origin = `http://127.0.0.1:${port}`, password = 'a-test-password-123456', salt = randomBytes(32);
  const hash = await scrypt(password, salt, 64, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
  const child = spawn(process.execPath, ['src/server.js'], {
    cwd: path.resolve(import.meta.dirname, '..'),
    env: { ...process.env, NODE_ENV: 'test', PORT: String(port), APP_ORIGIN: origin, MASTER_KEY: randomBytes(32).toString('base64'), OWNER_PASSWORD_SALT: salt.toString('base64'), OWNER_PASSWORD_HASH: hash.toString('base64'), DATA_DIR: path.join(dir, 'data'), RUNTIME_DIR: path.join(dir, 'ram') },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let stderr = ''; child.stderr.on('data', d => { stderr += d.toString(); });
  const request = (url, options = {}) => fetch(`${origin}${url}`, { redirect: 'manual', ...options });
  try {
    for (let i = 0; i < 50; i++) { try { await request('/login'); break; } catch { await new Promise(r => setTimeout(r, 50)); } }
    for (const target of ['/', '/app.js', '/style.css']) {
      const r = await request(target); assert.equal(r.status, 302, target); assert.equal(r.headers.get('location'), '/login');
    }
    assert.equal((await request('/api/state')).status, 401);
    assert.equal((await request('/api/history')).status, 401);
    assert.equal((await request('/api/downloads/123')).status, 401);
    const wsStatus = await new Promise((resolve, reject) => {
      const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`, { headers: { Origin: origin } });
      ws.on('unexpected-response', (_, response) => resolve(response.statusCode));
      ws.on('open', () => reject(Error('Unauthenticated WebSocket opened.')));
      ws.on('error', reject);
    });
    assert.equal(wsStatus, 401);
    assert.equal((await request('/login')).status, 200);
    assert.equal((await request('/login.js')).status, 200);
    const wrong = await request('/api/login', { method: 'POST', headers: { Origin: origin, 'Content-Type': 'application/json' }, body: JSON.stringify({ password: 'wrong' }) });
    assert.equal(wrong.status, 401);
    const denied = await request('/api/login', { method: 'POST', headers: { Origin: 'https://attacker.example', 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) });
    assert.equal(denied.status, 403);
    const login = await request('/api/login', { method: 'POST', headers: { Origin: origin, 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) });
    assert.equal(login.status, 200, stderr);
    const cookie = login.headers.get('set-cookie').split(';')[0];
    assert.match(login.headers.get('set-cookie'), /HttpOnly; SameSite=Strict/);
    assert.equal((await request('/', { headers: { Cookie: cookie } })).status, 200);
    const note = await request('/api/notes', { method: 'POST', headers: { Origin: origin, Cookie: cookie, 'Content-Type': 'application/json' }, body: JSON.stringify({ text: 'secret test note' }) });
    assert.equal(note.status, 200);
    assert.equal((await readFile(path.join(dir, 'data', 'state.enc'))).includes(Buffer.from('secret test note')), false);
    const logout = await request('/api/logout', { method: 'POST', headers: { Origin: origin, Cookie: cookie, 'Content-Type': 'application/json' }, body: '{}' });
    assert.equal(logout.status, 200);
    assert.equal((await request('/', { headers: { Cookie: cookie } })).status, 302);
  } finally {
    if (child.exitCode === null) { child.kill('SIGTERM'); await new Promise(resolve => child.once('exit', resolve)); }
    await rm(dir, { recursive: true, force: true });
  }
});
