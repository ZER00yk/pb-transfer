const $ = id => document.getElementById(id);
let state = null, socket = null, section = 'bookmarks', currentFrame = null, connected = false;
let toastTimer, resizeTimer, touchStart = null;
const profile = () => state?.profiles.find(p => p.id === state.activeProfileId);
const tab = () => profile()?.tabs.find(t => t.id === profile().activeTabId);
const make = (tag, className, value) => { const n = document.createElement(tag); if (className) n.className = className; if (value !== undefined) n.textContent = value; return n; };
function notify(message) { $('toast').textContent = message; $('toast').classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => $('toast').classList.remove('show'), 3500); }
async function api(url, method = 'GET', data) {
  const r = await fetch(url, { method, headers: data === undefined ? {} : { 'Content-Type': 'application/json' }, body: data === undefined ? undefined : JSON.stringify(data) });
  if (r.status === 401) { location.replace('/login'); throw Error('Sign in required.'); }
  const x = await r.json(); if (!r.ok) throw Error(x.error || 'Request failed.'); return x;
}
async function run(task, success) { try { await task(); if (success) notify(success); } catch (e) { notify(e.message); } }
function normalizedAddress(value) {
  const s = value.trim();
  if (!s) throw Error('Enter an address.');
  if (!s.includes('.') && !s.includes(':') || /\s/.test(s)) return `https://www.google.com/search?q=${encodeURIComponent(s)}`;
  return s;
}
function send(msg) { if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify(msg)); }
function input(kind, extra = {}) { send({ type: 'input', kind, ...extra }); }
function viewport() { const b = $('screen').getBoundingClientRect(); send({ type: 'viewport', width: Math.round(b.width), height: Math.round(b.height) }); }
function connect() {
  const scheme = location.protocol === 'https:' ? 'wss:' : 'ws:';
  socket = new WebSocket(`${scheme}//${location.host}/ws`); socket.binaryType = 'blob';
  socket.onopen = () => { connected = true; $('status').textContent = 'Connected'; viewport(); };
  socket.onmessage = e => {
    if (typeof e.data === 'string') {
      let msg; try { msg = JSON.parse(e.data); } catch { return; }
      if (msg.type === 'state') render(msg.value);
      if (msg.type === 'error') { $('loading').textContent = msg.message; notify(msg.message); }
      return;
    }
    const url = URL.createObjectURL(e.data);
    const old = currentFrame; currentFrame = url;
    $('frame').onload = () => { if (old) URL.revokeObjectURL(old); $('loading').classList.add('hidden'); };
    $('frame').src = url;
  };
  socket.onclose = () => { connected = false; $('status').textContent = 'Disconnected · reconnecting'; setTimeout(connect, 1800); };
}
function render(next) {
  state = next; const p = profile(), t = tab();
  $('profileSelect').replaceChildren(...state.profiles.map(item => { const o = make('option', '', item.name); o.value = item.id; return o; }));
  $('profileSelect').value = state.activeProfileId;
  $('tabs').replaceChildren(...(p?.tabs || []).map(item => {
    const b = make('div', `tab${item.id === p.activeTabId ? ' active' : ''}`); b.setAttribute('role', 'tab'); b.setAttribute('tabindex', '0'); b.setAttribute('aria-selected', String(item.id === p.activeTabId));
    b.append(make('span', 'tab-title', item.title || 'New tab'));
    const close = make('button', 'close', '×'); close.title = 'Close tab'; close.setAttribute('aria-label', `Close ${item.title || 'tab'}`);
    close.onclick = e => { e.stopPropagation(); run(() => api(`/api/tabs/${item.id}`, 'DELETE')); };
    b.onclick = () => run(() => api(`/api/tabs/${item.id}/activate`, 'POST', {}));
    b.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); e.stopPropagation(); b.click(); } };
    b.append(close); return b;
  }));
  if (document.activeElement !== $('address')) $('address').value = t?.url?.startsWith('http') ? t.url : '';
  const blank = !t || t.url === 'about:blank';
  $('start').classList.toggle('hidden', !blank);
  $('frame').style.visibility = blank ? 'hidden' : 'visible';
  const marked = p?.bookmarks.some(b => b.url === t?.url);
  $('bookmark').textContent = marked ? '★' : '☆';
  $('bookmark').setAttribute('aria-label', marked ? 'Remove bookmark' : 'Bookmark current page');
  document.title = `${t?.title || 'Private Browser'} · Private Browser`;
  if (!$('panel').classList.contains('hidden') && !$('panelContent').contains(document.activeElement)) renderPanel();
}
function openPanel(name = section) { section = name; $('panel').classList.remove('hidden'); renderPanel(); }
function listEntry(title, detail, actions = []) {
  const e = make('div', 'entry'); e.append(make('strong', '', title)); if (detail) e.append(make('small', '', detail));
  if (actions.length) { const row = make('div', 'entry-actions'); for (const [label, handler] of actions) { const b = make('button', '', label); b.onclick = handler; row.append(b); } e.append(row); } return e;
}
function heading(text) { return make('h2', '', text); }
function empty(text) { return make('p', 'empty', text); }
function button(text, fn, cls = 'secondary') { const b = make('button', cls, text); b.onclick = fn; return b; }
function openUrl(url) { run(async () => { const t = tab(); if (t) await api(`/api/tabs/${t.id}/navigate`, 'POST', { url }); else await api('/api/tabs', 'POST', { url }); $('panel').classList.add('hidden'); }); }
function renderPanel() {
  document.querySelectorAll('.panel-tabs button').forEach(b => b.classList.toggle('selected', b.dataset.section === section));
  const root = $('panelContent'); root.replaceChildren(); const p = profile(); if (!p) return;
  if (section === 'bookmarks') {
    root.append(heading('Bookmarks'));
    if (!p.bookmarks.length) root.append(empty('Save a page with the star beside the address bar.'));
    for (const item of p.bookmarks) root.append(listEntry(item.title, item.url, [['Open', () => openUrl(item.url)], ['Remove', () => run(() => api('/api/bookmarks', 'POST', { url: item.url }))]]));
  } else if (section === 'history') {
    root.append(heading('History'));
    const search = make('input'); search.placeholder = 'Search visited pages'; search.setAttribute('aria-label', 'Search history'); root.append(search);
    const results = make('div'); root.append(results);
    const show = q => { const matches = p.history.filter(h => `${h.title} ${h.url}`.toLowerCase().includes(q.toLowerCase())).slice(0, 100); results.replaceChildren(...matches.map(h => listEntry(h.title, `${new Date(h.at).toLocaleString()} · ${h.url}`, [['Open', () => openUrl(h.url)]]))); if (!matches.length) results.append(empty('No matching visits.')); };
    search.oninput = () => show(search.value); show('');
  } else if (section === 'notes') {
    root.append(heading('Notes'));
    const textarea = make('textarea'); textarea.placeholder = 'A note for this page…'; textarea.setAttribute('aria-label', 'New note'); root.append(textarea);
    const save = button('Save note', () => run(async () => { await api('/api/notes', 'POST', { text: textarea.value, url: tab()?.url || '' }); textarea.value = ''; renderPanel(); }, 'Note saved.'), 'primary'); save.style.marginTop = '8px'; root.append(save);
    if (!p.notes.length) root.append(empty('Your notes will appear here.'));
    for (const n of p.notes) { const e = listEntry(n.url || 'General note', new Date(n.at).toLocaleString(), [['Delete', () => run(() => api(`/api/notes/${n.id}`, 'DELETE'))]]); e.append(make('p', '', n.text)); root.append(e); }
  } else if (section === 'downloads') {
    root.append(heading('Downloads'));
    const items = state.downloads.filter(d => d.profileId === p.id);
    if (!items.length) root.append(empty('Files downloaded in this profile appear here.'));
    for (const d of items) root.append(listEntry(d.name, new Date(d.at).toLocaleString(), [['Download', () => { location.href = `/api/downloads/${d.id}`; }]]));
  } else {
    root.append(heading('Profiles & preferences'));
    const row = make('div', 'row'); row.append(button('New profile', () => { const name = prompt('Profile name'); if (name?.trim()) run(() => api('/api/profiles', 'POST', { name: name.trim() })); }), button('Rename', () => { const name = prompt('New name', p.name); if (name?.trim()) run(() => api(`/api/profiles/${p.id}/rename`, 'POST', { name: name.trim() })); })); root.append(row);
    const quality = make('div', 'field'), qlabel = make('label', '', `Image quality: ${state.preferences.quality}`), qinput = make('input'); qinput.type = 'range'; qinput.min = 40; qinput.max = 90; qinput.value = state.preferences.quality; qinput.oninput = () => qlabel.textContent = `Image quality: ${qinput.value}`; qinput.onchange = () => run(() => api('/api/preferences', 'POST', { quality: Number(qinput.value) })); quality.append(qlabel, qinput); root.append(quality);
    const speed = make('div', 'field'), slabel = make('label', '', `Frames per second: ${state.preferences.fps}`), sinput = make('input'); sinput.type = 'range'; sinput.min = 2; sinput.max = 12; sinput.value = state.preferences.fps; sinput.oninput = () => slabel.textContent = `Frames per second: ${sinput.value}`; sinput.onchange = () => run(() => api('/api/preferences', 'POST', { fps: Number(sinput.value) })); speed.append(slabel, sinput); root.append(speed);
    root.append(empty('The browser profile saves when you leave. Save now to close Chromium and encrypt a fresh checkpoint.'));
    root.append(button('Save profile now', () => run(() => api('/api/save', 'POST', {}), 'Profile saved'), 'primary'));
  }
}

$('panel').classList.add('hidden');
document.querySelectorAll('.panel-tabs button').forEach(b => b.onclick = () => openPanel(b.dataset.section));
$('panelToggle').onclick = () => $('panel').classList.contains('hidden') ? openPanel() : $('panel').classList.add('hidden');
$('closePanel').onclick = () => $('panel').classList.add('hidden');
$('newTab').onclick = () => run(() => api('/api/tabs', 'POST', {}));
$('profileSelect').onchange = e => run(() => api(`/api/profiles/${e.target.value}/select`, 'POST', {}));
$('addressForm').onsubmit = e => { e.preventDefault(); run(async () => { const t = tab(); const url = normalizedAddress($('address').value); if (t) await api(`/api/tabs/${t.id}/navigate`, 'POST', { url }); else await api('/api/tabs', 'POST', { url }); $('address').blur(); }); };
for (const id of ['back', 'forward', 'reload']) $(id).onclick = () => { if (tab()) run(() => api(`/api/tabs/${tab().id}/action`, 'POST', { command: id })); };
$('bookmark').onclick = () => { const t = tab(); if (t?.url?.startsWith('http')) run(() => api('/api/bookmarks', 'POST', { url: t.url, title: t.title })); };
$('save').onclick = () => run(() => api('/api/save', 'POST', {}), 'Profile saved');
$('signout').onclick = () => run(async () => { await api('/api/logout', 'POST', {}); location.replace('/login'); });
document.querySelectorAll('.shortcuts button').forEach(b => b.onclick = () => openUrl(b.dataset.url));
$('keyboardToggle').onclick = () => $('keyboard').classList.toggle('hidden');
$('controlsToggle').onclick = () => $('controls').classList.toggle('hidden');
$('fullScreen').onclick = () => document.fullscreenElement ? document.exitFullscreen() : $('workspace').requestFullscreen().catch(e => notify(e.message));
const type = () => { const value = $('typeText').value; if (value) { input('text', { text: value }); $('typeText').value = ''; } };
$('sendText').onclick = type; $('typeText').onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); type(); } };
document.querySelectorAll('[data-key]').forEach(b => b.onclick = () => { input('keyDown', { key: b.dataset.key }); input('keyUp', { key: b.dataset.key }); });
document.querySelectorAll('[data-hold]').forEach(b => {
  b.onpointerdown = e => { e.preventDefault(); b.setPointerCapture(e.pointerId); input('keyDown', { key: b.dataset.hold }); };
  b.onpointerup = b.onpointercancel = e => { e.preventDefault(); input('keyUp', { key: b.dataset.hold }); };
});
document.addEventListener('keydown', e => {
  if (e.target.closest('input,textarea,select,button') || e.ctrlKey && ['l', 't', 'w'].includes(e.key.toLowerCase())) return;
  e.preventDefault(); input('keyDown', { key: e.key });
});
document.addEventListener('keyup', e => { if (e.target.closest('input,textarea,select,button')) return; e.preventDefault(); input('keyUp', { key: e.key }); });
function point(e) {
  const b = $('screen').getBoundingClientRect(), img = $('frame');
  const iw = img.naturalWidth || b.width, ih = img.naturalHeight || b.height;
  const scale = Math.min(b.width / iw, b.height / ih), w = iw * scale, h = ih * scale;
  return { x: Math.max(0, Math.min(iw, Math.round((e.clientX - b.left - (b.width - w) / 2) / scale))), y: Math.max(0, Math.min(ih, Math.round((e.clientY - b.top - (b.height - h) / 2) / scale))) };
}
$('screen').onpointerdown = e => { if (e.target.closest('button')) return; e.preventDefault(); $('screen').focus(); $('screen').setPointerCapture(e.pointerId); touchStart = { x: e.clientX, y: e.clientY, moved: false }; if (e.pointerType !== 'touch') input('down', { ...point(e), button: e.button === 2 ? 'right' : 'left' }); };
$('screen').onpointermove = e => { if (!touchStart) { if (e.pointerType === 'mouse') input('move', point(e)); return; } if (e.pointerType === 'touch') { const dx = e.clientX - touchStart.x, dy = e.clientY - touchStart.y; if (Math.abs(dx) + Math.abs(dy) > 8) touchStart.moved = true; if (touchStart.moved) input('wheel', { dx: -dx, dy: -dy }); touchStart.x = e.clientX; touchStart.y = e.clientY; } else input('move', point(e)); };
$('screen').onpointerup = e => { if (!touchStart) return; if (e.pointerType === 'touch') { if (!touchStart.moved) input('tap', point(e)); } else input('up', { ...point(e), button: e.button === 2 ? 'right' : 'left' }); touchStart = null; };
$('screen').onpointercancel = () => { touchStart = null; input('up'); };
$('screen').oncontextmenu = e => e.preventDefault();
$('screen').onwheel = e => { e.preventDefault(); input('wheel', { dx: e.deltaX, dy: e.deltaY }); };
new ResizeObserver(() => { clearTimeout(resizeTimer); resizeTimer = setTimeout(viewport, 150); }).observe($('screen'));
api('/api/state').then(render).catch(e => { $('loading').textContent = e.message; notify(e.message); });
connect();
